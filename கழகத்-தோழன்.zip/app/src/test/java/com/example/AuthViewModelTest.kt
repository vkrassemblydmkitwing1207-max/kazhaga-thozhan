package com.example

import com.example.ui.auth.AuthViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AuthViewModelTest {

    @Test
    fun `phone input normalizes +91 and filters non-digits`() {
        val vm = AuthViewModel()
        vm.onPhoneDigitsChanged("+91 98765-43210")
        assertEquals("9876543210", vm.uiState.value.phoneDigits)
        assertNull(vm.uiState.value.errorMessage)
    }

    @Test
    fun `sendOtp with invalid Indian number sets Tamil validation error without leaving phone screen`() {
        val vm = AuthViewModel()
        vm.onPhoneDigitsChanged("1234567890")
        vm.sendOtp(activity = null, isResend = false, onAutoVerified = {})
        assertNotNull(vm.uiState.value.errorMessage)
        assertFalse(vm.uiState.value.isOtpScreenVisible)
    }

    @Test
    fun `otp input caps at 6 digits and verifyOtp rejects missing session`() {
        val vm = AuthViewModel()
        vm.onOtpCodeChanged("12ab345678")
        assertEquals("123456", vm.uiState.value.otpCode)

        vm.verifyOtp(onAuthSuccess = {})
        assertNotNull(vm.uiState.value.errorMessage)
    }

    @Test
    fun `goBackToPhoneEntry clears OTP code and error state`() {
        val vm = AuthViewModel()
        vm.onOtpCodeChanged("654321")
        vm.setError("பிழை")
        vm.goBackToPhoneEntry()
        assertEquals("", vm.uiState.value.otpCode)
        assertNull(vm.uiState.value.errorMessage)
        assertFalse(vm.uiState.value.isOtpScreenVisible)
    }
}
