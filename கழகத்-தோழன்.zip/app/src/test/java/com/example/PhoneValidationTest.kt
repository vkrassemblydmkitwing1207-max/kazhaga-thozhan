package com.example

import com.example.ui.auth.IndianPhoneValidator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PhoneValidationTest {

    @Test
    fun `normalizeInput strips +91 and leading zero cleanly`() {
        assertEquals("9876543210", IndianPhoneValidator.normalizeInput("+919876543210"))
        assertEquals("9876543210", IndianPhoneValidator.normalizeInput("919876543210"))
        assertEquals("9876543210", IndianPhoneValidator.normalizeInput("09876543210"))
        assertEquals("9876543210", IndianPhoneValidator.normalizeInput("98765 43210"))
    }

    @Test
    fun `isValid accepts Indian 10-digit numbers starting with 6 to 9`() {
        assertTrue(IndianPhoneValidator.isValid("6000000000"))
        assertTrue(IndianPhoneValidator.isValid("7123456789"))
        assertTrue(IndianPhoneValidator.isValid("8123456789"))
        assertTrue(IndianPhoneValidator.isValid("9876543210"))
        assertNull(IndianPhoneValidator.validationErrorTamil("9876543210"))
    }

    @Test
    fun `isValid rejects short numbers and invalid prefixes`() {
        assertFalse(IndianPhoneValidator.isValid("5876543210"))
        assertFalse(IndianPhoneValidator.isValid("1234567890"))
        assertFalse(IndianPhoneValidator.isValid("98765"))
        assertNotNull(IndianPhoneValidator.validationErrorTamil("5876543210"))
        assertNotNull(IndianPhoneValidator.validationErrorTamil("98765"))
    }

    @Test
    fun `toE164 formats +91 prefix correctly`() {
        assertEquals("+919876543210", IndianPhoneValidator.toE164("9876543210"))
    }
}
