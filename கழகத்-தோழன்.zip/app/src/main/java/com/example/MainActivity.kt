package com.example

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.model.KazhagaConstants
import com.example.data.model.UiState
import com.example.data.repository.KazhagaRepository
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.secureSignOut
import com.example.ui.registration.MemberRegistrationScreen
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DirectoryScreen
import com.example.ui.screens.ErrorBanner
import com.example.ui.screens.LoadingBox
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.KazhagaThozhanTheme
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PureWhite
import com.example.ui.viewmodel.KazhagaViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KazhagaThozhanTheme {
                AppContent()
            }
        }
    }
}

@Composable
fun AppContent() {
    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }
    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose { Firebase.auth.removeAuthStateListener(listener) }
    }

    val user = currentUser
    if (user == null) {
        AuthScreen(onAuthSuccess = { currentUser = Firebase.auth.currentUser })
    } else {
        val uid = user.uid
        key(uid) {
            AuthenticatedKazhagaRoot(currentUserId = uid)
        }
    }
}

private data class NavDestination(
    val index: Int,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthenticatedKazhagaRoot(currentUserId: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val viewModel: KazhagaViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                KazhagaViewModel(KazhagaRepository(db), currentUserId)
            }
        }
    )

    val profileState by viewModel.profileState.collectAsStateWithLifecycle()
    val adminRecordState by viewModel.adminRecordState.collectAsStateWithLifecycle()
    val ownAdminRequestState by viewModel.ownAdminRequestState.collectAsStateWithLifecycle()
    val isChiefAdmin by viewModel.isChiefAdmin.collectAsStateWithLifecycle()
    val isApprovedAdmin by viewModel.isApprovedAdmin.collectAsStateWithLifecycle()
    val notificationsState by viewModel.notificationsState.collectAsStateWithLifecycle()
    val directoryState by viewModel.directoryState.collectAsStateWithLifecycle()
    val allMembersAdminState by viewModel.allMembersAdminState.collectAsStateWithLifecycle()
    val allAdminsState by viewModel.allAdminsState.collectAsStateWithLifecycle()
    val adminRequestsState by viewModel.adminRequestsState.collectAsStateWithLifecycle()
    val isMutating by viewModel.isMutating.collectAsStateWithLifecycle()
    val feedback by viewModel.feedback.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(feedback) {
        feedback?.let {
            snackbarHostState.showSnackbar(it.message)
            viewModel.clearFeedback()
        }
    }

    val handleSignOut: () -> Unit = {
        secureSignOut(credentialManager = credentialManager, scope = scope)
    }

    when (val pState = profileState) {
        is UiState.Loading -> {
            Scaffold { innerPadding ->
                Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                    LoadingBox("உறுப்பினர் சுயவிவரம் சரிபார்க்கப்படுகிறது...")
                }
            }
        }

        is UiState.Error -> {
            Scaffold { innerPadding ->
                Box(modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp)) {
                    ErrorBanner(pState.message)
                }
            }
        }

        is UiState.Success -> {
            val member = pState.data
            if (member == null) {
                MemberRegistrationScreen(
                    initialFullName = viewModel.userDisplayName,
                    initialPhoneNumber = viewModel.userPhoneNumber,
                    isSubmitting = isMutating,
                    errorMessage = if (feedback?.isError == true) feedback?.message else null,
                    onSubmit = { name, phone, union, town, panchayat, ward, designation ->
                        viewModel.registerMember(name, phone, union, town, panchayat, ward, designation)
                    },
                    onSignOut = handleSignOut
                )
            } else {
                var selectedTab by remember { mutableIntStateOf(0) }

                BackHandler(enabled = selectedTab != 0) {
                    selectedTab = 0
                }

                val destinations = remember(isApprovedAdmin) {
                    buildList {
                        add(NavDestination(0, "முகப்பு", Icons.Filled.Home, Icons.Outlined.Home))
                        add(NavDestination(1, "அறிவிப்பு", Icons.Filled.Campaign, Icons.Outlined.Campaign))
                        add(NavDestination(2, "தோழர்கள்", Icons.Filled.Groups, Icons.Outlined.Groups))
                        add(NavDestination(3, "சுயவிவரம்", Icons.Filled.Person, Icons.Outlined.Person))
                        if (isApprovedAdmin) {
                            add(NavDestination(4, "நிர்வாகம்", Icons.Filled.AdminPanelSettings, Icons.Outlined.AdminPanelSettings))
                        }
                    }
                }

                // Reset tab if admin privileges were revoked while on admin tab
                LaunchedEffect(isApprovedAdmin) {
                    if (!isApprovedAdmin && selectedTab == 4) {
                        selectedTab = 0
                    }
                }

                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    val useRail = maxWidth >= 600.dp

                    Scaffold(
                        topBar = {
                            TopAppBar(
                                title = {
                                    Column {
                                        Text(
                                            text = "கழகத் தோழன்",
                                            style = MaterialTheme.typography.titleLarge,
                                            color = PureWhite,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH} மாவட்டம்",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = PureWhite.copy(alpha = 0.8f)
                                        )
                                    }
                                },
                                colors = TopAppBarDefaults.topAppBarColors(
                                    containerColor = ObsidianBlack,
                                    titleContentColor = PureWhite
                                ),
                                modifier = Modifier.statusBarsPadding()
                            )
                        },
                        bottomBar = {
                            if (!useRail) {
                                NavigationBar(
                                    containerColor = MaterialTheme.colorScheme.surface,
                                    contentColor = CrimsonRed
                                ) {
                                    destinations.forEach { dest ->
                                        val isSelected = selectedTab == dest.index
                                        NavigationBarItem(
                                            selected = isSelected,
                                            onClick = { selectedTab = dest.index },
                                            icon = {
                                                Icon(
                                                    imageVector = if (isSelected) dest.selectedIcon else dest.unselectedIcon,
                                                    contentDescription = dest.label
                                                )
                                            },
                                            label = { Text(dest.label, maxLines = 1) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = PureWhite,
                                                selectedTextColor = CrimsonRed,
                                                indicatorColor = CrimsonRed,
                                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        )
                                    }
                                }
                            }
                        },
                        snackbarHost = {
                            SnackbarHost(hostState = snackbarHostState) { data ->
                                Snackbar(
                                    snackbarData = data,
                                    containerColor = ObsidianBlack,
                                    contentColor = PureWhite
                                )
                            }
                        },
                        contentWindowInsets = WindowInsets(0, 0, 0, 0)
                    ) { innerPadding ->
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            if (useRail) {
                                NavigationRail(
                                    containerColor = MaterialTheme.colorScheme.surface,
                                    modifier = Modifier.fillMaxHeight()
                                ) {
                                    destinations.forEach { dest ->
                                        val isSelected = selectedTab == dest.index
                                        NavigationRailItem(
                                            selected = isSelected,
                                            onClick = { selectedTab = dest.index },
                                            icon = {
                                                Icon(
                                                    imageVector = if (isSelected) dest.selectedIcon else dest.unselectedIcon,
                                                    contentDescription = dest.label
                                                )
                                            },
                                            label = { Text(dest.label) },
                                            colors = NavigationRailItemDefaults.colors(
                                                selectedIconColor = PureWhite,
                                                selectedTextColor = CrimsonRed,
                                                indicatorColor = CrimsonRed
                                            )
                                        )
                                    }
                                }
                            }

                            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                                when (selectedTab) {
                                    0 -> DashboardScreen(
                                        member = member,
                                        isChiefAdmin = isChiefAdmin,
                                        isApprovedAdmin = isApprovedAdmin,
                                        directoryState = directoryState,
                                        notificationsState = notificationsState,
                                        onNavigateToTab = { selectedTab = it }
                                    )

                                    1 -> NotificationsScreen(
                                        member = member,
                                        isApprovedAdmin = isApprovedAdmin,
                                        isMutating = isMutating,
                                        notificationsState = notificationsState,
                                        onPublishNotification = viewModel::publishNotification,
                                        onDeleteNotification = viewModel::deleteNotification
                                    )

                                    2 -> DirectoryScreen(directoryState = directoryState)

                                    3 -> ProfileScreen(
                                        member = member,
                                        isChiefAdmin = isChiefAdmin,
                                        isApprovedAdmin = isApprovedAdmin,
                                        ownAdminRequestState = ownAdminRequestState,
                                        isMutating = isMutating,
                                        onUpdateProfile = viewModel::updateProfile,
                                        onSubmitAdminRequest = viewModel::submitAdminRequest,
                                        onSignOut = handleSignOut
                                    )

                                    4 -> {
                                        if (isApprovedAdmin) {
                                            AdminDashboardScreen(
                                                currentMember = member,
                                                isChiefAdmin = isChiefAdmin,
                                                ownAdminRecord = (adminRecordState as? UiState.Success)?.data,
                                                allMembersState = allMembersAdminState,
                                                allAdminsState = allAdminsState,
                                                adminRequestsState = adminRequestsState,
                                                isMutating = isMutating,
                                                onBootstrapChiefAdmin = viewModel::bootstrapChiefAdmin,
                                                onVerifyMember = viewModel::verifyMember,
                                                onPromoteToAdmin = viewModel::createAndApproveAdmin,
                                                onApproveAdminRequest = viewModel::approveAdminRequest,
                                                onRejectAdminRequest = viewModel::rejectAdminRequest,
                                                onSetAdminApproval = viewModel::setAdminApproval
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
