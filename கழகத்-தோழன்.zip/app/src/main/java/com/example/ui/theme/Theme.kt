package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val KazhagaDarkColorScheme = darkColorScheme(
    primary = CrimsonRed,
    onPrimary = PureWhite,
    primaryContainer = CrimsonRedDark,
    onPrimaryContainer = PureWhite,
    secondary = PureWhite,
    onSecondary = ObsidianBlack,
    secondaryContainer = GraphiteSurface,
    onSecondaryContainer = PureWhite,
    tertiary = CrimsonAccent,
    onTertiary = PureWhite,
    background = ObsidianBlack,
    onBackground = PureWhite,
    surface = CharcoalBlack,
    onSurface = PureWhite,
    surfaceVariant = GraphiteSurface,
    onSurfaceVariant = MutedTextDark,
    outline = SlateBorderDark,
    error = ErrorRed,
    onError = PureWhite,
    errorContainer = ErrorRedContainer,
    onErrorContainer = CrimsonRedDark
)

private val KazhagaLightColorScheme = lightColorScheme(
    primary = CrimsonRed,
    onPrimary = PureWhite,
    primaryContainer = CrimsonRedLight,
    onPrimaryContainer = CrimsonRedDark,
    secondary = ObsidianBlack,
    onSecondary = PureWhite,
    secondaryContainer = SubtleSurfaceGray,
    onSecondaryContainer = ObsidianBlack,
    tertiary = CrimsonRedDark,
    onTertiary = PureWhite,
    background = SoftPaperWhite,
    onBackground = ObsidianBlack,
    surface = PureWhite,
    onSurface = ObsidianBlack,
    surfaceVariant = SubtleSurfaceGray,
    onSurfaceVariant = MutedTextLight,
    outline = SubtleBorderLight,
    error = ErrorRed,
    onError = PureWhite,
    errorContainer = ErrorRedContainer,
    onErrorContainer = CrimsonRedDark
)

val KazhagaShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(26.dp)
)

@Composable
fun KazhagaThozhanTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) KazhagaDarkColorScheme else KazhagaLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = KazhagaShapes,
        content = content
    )
}
