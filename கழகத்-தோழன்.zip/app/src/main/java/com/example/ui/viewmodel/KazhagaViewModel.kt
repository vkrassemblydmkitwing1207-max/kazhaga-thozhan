package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AdminRecord
import com.example.data.model.AdminRequest
import com.example.data.model.DirectoryMember
import com.example.data.model.KazhagaConstants
import com.example.data.model.NotificationItem
import com.example.data.model.UiState
import com.example.data.model.UserMember
import com.example.data.remote.toTamilErrorMessage
import com.example.data.repository.KazhagaRepository
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ActionFeedback(
    val message: String,
    val isError: Boolean = false
)

class KazhagaViewModel(
    private val repository: KazhagaRepository,
    val currentUserId: String
) : ViewModel() {

    private val currentUser = Firebase.auth.currentUser
    private val isBootstrapChiefEmail: Boolean =
        currentUser?.email == KazhagaConstants.BOOTSTRAP_CHIEF_ADMIN_EMAIL &&
            currentUser.isEmailVerified

    val userPhoneNumber: String = currentUser?.phoneNumber.orEmpty()
    val userDisplayName: String = currentUser?.displayName.orEmpty()

    private val _isMutating = MutableStateFlow(false)
    val isMutating: StateFlow<Boolean> = _isMutating.asStateFlow()

    private val _feedback = MutableStateFlow<ActionFeedback?>(null)
    val feedback: StateFlow<ActionFeedback?> = _feedback.asStateFlow()

    val profileState: StateFlow<UiState<UserMember?>> =
        repository.observeCurrentUserProfile(currentUserId)
            .toUiState("Profile")
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    val adminRecordState: StateFlow<UiState<AdminRecord?>> =
        repository.observeAdminRecord(currentUserId)
            .toUiState("AdminRecord")
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    val ownAdminRequestState: StateFlow<UiState<AdminRequest?>> =
        repository.observeOwnAdminRequest(currentUserId)
            .toUiState("OwnAdminRequest")
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    val isChiefAdmin: StateFlow<Boolean> =
        combine(adminRecordState, profileState) { adminUi, _ ->
            val record = (adminUi as? UiState.Success)?.data
            isBootstrapChiefEmail || (
                record != null &&
                    record.approved &&
                    record.adminLevel == KazhagaConstants.ROLE_CHIEF_ADMIN
                )
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = isBootstrapChiefEmail
        )

    val isApprovedAdmin: StateFlow<Boolean> =
        combine(isChiefAdmin, adminRecordState) { chief, adminUi ->
            val record = (adminUi as? UiState.Success)?.data
            chief || (record != null && record.approved)
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = isBootstrapChiefEmail
        )

    val notificationsState: StateFlow<UiState<List<NotificationItem>>> =
        repository.observeNotifications(currentUserId)
            .toUiState("Notifications")
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    val directoryState: StateFlow<UiState<List<DirectoryMember>>> =
        repository.observeDirectory(currentUserId)
            .toUiState("Directory")
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    @OptIn(ExperimentalCoroutinesApi::class)
    val allMembersAdminState: StateFlow<UiState<List<UserMember>>> =
        isApprovedAdmin.flatMapLatest { approved ->
            if (!approved) {
                flowOf(UiState.Success(emptyList()))
            } else {
                repository.observeAllUsersForAdmin(currentUserId).toUiState("AllMembers")
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Success(emptyList())
        )

    @OptIn(ExperimentalCoroutinesApi::class)
    val allAdminsState: StateFlow<UiState<List<AdminRecord>>> =
        isApprovedAdmin.flatMapLatest { approved ->
            if (!approved) {
                flowOf(UiState.Success(emptyList()))
            } else {
                repository.observeAllAdmins(currentUserId).toUiState("AllAdmins")
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Success(emptyList())
        )

    @OptIn(ExperimentalCoroutinesApi::class)
    val adminRequestsState: StateFlow<UiState<List<AdminRequest>>> =
        isChiefAdmin.flatMapLatest { chief ->
            if (!chief) {
                flowOf(UiState.Success(emptyList()))
            } else {
                repository.observeAdminRequestsForChief(currentUserId).toUiState("AdminRequests")
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Success(emptyList())
        )

    fun clearFeedback() {
        _feedback.value = null
    }

    fun registerMember(
        fullName: String,
        mobileNumber: String,
        unionName: String,
        townVillage: String,
        panchayat: String,
        ward: String,
        designation: String
    ) {
        launchMutation("உறுப்பினர் பதிவு வெற்றிகரமாக நிறைவடைந்தது!") {
            repository.registerMember(
                fullName = fullName,
                mobileNumber = mobileNumber,
                unionName = unionName,
                townVillage = townVillage,
                panchayat = panchayat,
                ward = ward,
                designation = designation
            )
        }
    }

    fun updateProfile(
        fullName: String,
        mobileNumber: String,
        unionName: String,
        townVillage: String,
        panchayat: String,
        ward: String,
        designation: String
    ) {
        launchMutation("சுயவிவரம் வெற்றிகரமாகப் புதுப்பிக்கப்பட்டது.") {
            repository.updateOwnProfile(
                fullName = fullName,
                mobileNumber = mobileNumber,
                unionName = unionName,
                townVillage = townVillage,
                panchayat = panchayat,
                ward = ward,
                designation = designation
            )
        }
    }

    fun submitAdminRequest(
        member: UserMember,
        requestedDesignation: String,
        reason: String
    ) {
        launchMutation("நிர்வாகி அங்கீகாரக் கோரிக்கை மாவட்ட தலைமை நிர்வாகிக்கு அனுப்பப்பட்டது.") {
            repository.submitAdminRequest(member, requestedDesignation, reason)
        }
    }

    fun bootstrapChiefAdmin(member: UserMember) {
        launchMutation("மாவட்ட தலைமை நிர்வாகி கணக்கு இயக்கப்பட்டது.") {
            repository.bootstrapChiefAdminRecord(member)
        }
    }

    fun createAndApproveAdmin(
        targetMember: UserMember,
        unionScope: String,
        hasPendingRequest: Boolean
    ) {
        launchMutation("${targetMember.fullName} நிர்வாகியாக அங்கீகரிக்கப்பட்டார்.") {
            repository.createAndApproveAdmin(targetMember, unionScope, hasPendingRequest)
        }
    }

    fun approveAdminRequest(request: AdminRequest) {
        launchMutation("${request.fullName} நிர்வாகியாக அங்கீகரிக்கப்பட்டார்.") {
            repository.approveAdminRequest(request)
        }
    }

    fun rejectAdminRequest(userId: String) {
        launchMutation("கோரிக்கை நிராகரிக்கப்பட்டது.") {
            repository.rejectAdminRequest(userId)
        }
    }

    fun setAdminApproval(adminRecord: AdminRecord, approved: Boolean) {
        val msg = if (approved) {
            "${adminRecord.fullName} நிர்வாகி அனுமதி வழங்கப்பட்டது."
        } else {
            "${adminRecord.fullName} நிர்வாகி அனுமதி நிறுத்தப்பட்டது."
        }
        launchMutation(msg) {
            repository.setAdminApproval(adminRecord, approved)
        }
    }

    fun verifyMember(memberUid: String, verified: Boolean, status: String) {
        val msg = if (verified) "உறுப்பினர் சரிபார்க்கப்பட்டார்." else "உறுப்பினர் நிலை புதுப்பிக்கப்பட்டது."
        launchMutation(msg) {
            repository.verifyMember(memberUid, verified, status)
        }
    }

    fun publishNotification(
        title: String,
        message: String,
        category: String,
        targetUnion: String,
        authorName: String,
        priority: String
    ) {
        launchMutation("அறிவிப்பு வெளியிடப்பட்டது.") {
            repository.publishNotification(
                title = title,
                message = message,
                category = category,
                targetUnion = targetUnion,
                authorName = authorName,
                priority = priority
            )
        }
    }

    fun deleteNotification(notificationId: String) {
        launchMutation("அறிவிப்பு நீக்கப்பட்டது.") {
            repository.deleteNotification(notificationId)
        }
    }

    private fun launchMutation(successMessage: String, block: suspend () -> Result<Unit>) {
        if (_isMutating.value) return
        viewModelScope.launch {
            _isMutating.value = true
            val result = block()
            _isMutating.value = false
            result.onSuccess {
                _feedback.value = ActionFeedback(successMessage, isError = false)
            }.onFailure { error ->
                _feedback.value = ActionFeedback(toTamilErrorMessage(error), isError = true)
            }
        }
    }

    private fun <T> Flow<T>.toUiState(streamName: String): Flow<UiState<T>> =
        this.map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing $streamName", rootError)
                emit(UiState.Error(toTamilErrorMessage(rootError)))
            }

    private companion object {
        const val TAG = "KazhagaVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
