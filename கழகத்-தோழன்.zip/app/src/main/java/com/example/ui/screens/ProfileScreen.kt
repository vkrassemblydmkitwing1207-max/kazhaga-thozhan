package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AdminRequest
import com.example.data.model.KazhagaConstants
import com.example.data.model.UiState
import com.example.data.model.UserMember
import com.example.data.model.memberStatusDisplayTamil
import com.example.data.model.roleDisplayTamil
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PureWhite

@Composable
fun ProfileScreen(
    member: UserMember,
    isChiefAdmin: Boolean,
    isApprovedAdmin: Boolean,
    ownAdminRequestState: UiState<AdminRequest?>,
    isMutating: Boolean,
    onUpdateProfile: (
        fullName: String,
        mobileNumber: String,
        unionName: String,
        townVillage: String,
        panchayat: String,
        ward: String,
        designation: String
    ) -> Unit,
    onSubmitAdminRequest: (
        member: UserMember,
        requestedDesignation: String,
        reason: String
    ) -> Unit,
    onSignOut: () -> Unit
) {
    var showEditDialog by remember { mutableStateOf(false) }
    var showAdminRequestDialog by remember { mutableStateOf(false) }
    var showLogoutConfirm by remember { mutableStateOf(false) }

    val ownRequest = (ownAdminRequestState as? UiState.Success)?.data
    val effectiveRole = when {
        isChiefAdmin -> KazhagaConstants.ROLE_CHIEF_ADMIN
        isApprovedAdmin -> KazhagaConstants.ROLE_ADMIN
        else -> member.role
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            MemberDigitalIdCard(
                member = member,
                isChiefAdmin = isChiefAdmin,
                isApprovedAdmin = isApprovedAdmin
            )

            // Profile Details Card
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "உறுப்பினர் விவரங்கள்",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        OutlinedButton(
                            onClick = { showEditDialog = true },
                            modifier = Modifier.testTag("edit_profile_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("திருத்து")
                        }
                    }

                    ProfileFieldRow("முழுப் பெயர்", member.fullName)
                    ProfileFieldRow("கைபேசி எண்", member.mobileNumber)
                    ProfileFieldRow("மாவட்டம்", member.district)
                    ProfileFieldRow("ஒன்றியம் / நகரம்", member.unionName)
                    ProfileFieldRow("ஊர் / கிராமம்", member.townVillage)
                    ProfileFieldRow("ஊராட்சி", member.panchayat)
                    ProfileFieldRow("வார்டு எண்", member.ward)
                    ProfileFieldRow("பொறுப்பு", member.designation.ifBlank { "உறுப்பினர்" })
                    ProfileFieldRow("உறுப்பினர் நிலை", memberStatusDisplayTamil(member.memberStatus))
                    ProfileFieldRow("Firebase UID", member.userId)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "சரிபார்ப்பு",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        VerifiedStatusChip(verified = member.verified)
                    }
                }
            }

            // Server-verified Role & Security Card
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = CrimsonRed
                        )
                        Text(
                            text = "அதிகார நிலை (சேவையக சரிபார்ப்பு)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    ProfileFieldRow("தற்போதைய பங்கு", roleDisplayTamil(effectiveRole))
                    Text(
                        text = "உறுப்பினர்கள் தங்கள் பங்கைத் தாங்களே மாற்ற இயலாது. விழுப்புரம் தெற்கு மாவட்ட தலைமை நிர்வாகி மட்டுமே நிர்வாகி கணக்குகளை உருவாக்கி அங்கீகரிக்க முடியும்.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (!isApprovedAdmin) {
                        HorizontalDivider()
                        if (ownRequest != null) {
                            val statusLabel = when (ownRequest.status) {
                                "approved" -> "அங்கீகரிக்கப்பட்டது"
                                "rejected" -> "நிராகரிக்கப்பட்டது"
                                else -> "மாவட்ட தலைமை நிர்வாகி பரிசீலனையில்"
                            }
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = MaterialTheme.shapes.small,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "நிர்வாகி கோரிக்கை நிலை: $statusLabel",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "கோரிய பொறுப்பு: ${ownRequest.requestedDesignation}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        } else {
                            OutlinedButton(
                                onClick = { showAdminRequestDialog = true },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("request_admin_button")
                            ) {
                                Icon(Icons.Default.AdminPanelSettings, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("நிர்வாகி அங்கீகாரம் கோரவும்")
                            }
                        }
                    }
                }
            }

            // Secure Logout Button
            Button(
                onClick = { showLogoutConfirm = true },
                colors = ButtonDefaults.buttonColors(
                    containerColor = ObsidianBlack,
                    contentColor = PureWhite
                ),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("secure_logout_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("பாதுகாப்பாக வெளியேறு (Logout)", style = MaterialTheme.typography.labelLarge)
            }
        }
    }

    if (showEditDialog) {
        EditProfileDialog(
            member = member,
            isMutating = isMutating,
            onDismiss = { showEditDialog = false },
            onSave = { name, phone, union, town, panchayat, ward, desig ->
                onUpdateProfile(name, phone, union, town, panchayat, ward, desig)
                showEditDialog = false
            }
        )
    }

    if (showAdminRequestDialog) {
        AdminRequestDialog(
            isMutating = isMutating,
            onDismiss = { showAdminRequestDialog = false },
            onSubmit = { requestedDesignation, reason ->
                onSubmitAdminRequest(member, requestedDesignation, reason)
                showAdminRequestDialog = false
            }
        )
    }

    if (showLogoutConfirm) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirm = false },
            title = { Text("பாதுகாப்பான வெளியேற்றம்", fontWeight = FontWeight.Bold) },
            text = { Text("கழகத் தோழன் செயலியிலிருந்து வெளியேற விரும்புகிறீர்களா?") },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutConfirm = false
                        onSignOut()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed, contentColor = PureWhite)
                ) {
                    Text("வெளியேறு")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirm = false }) {
                    Text("ரத்து")
                }
            }
        )
    }
}

@Composable
private fun ProfileFieldRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(0.42f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(0.58f)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditProfileDialog(
    member: UserMember,
    isMutating: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, String, String, String) -> Unit
) {
    var fullName by remember { mutableStateOf(member.fullName) }
    var mobileNumber by remember { mutableStateOf(member.mobileNumber) }
    var unionName by remember { mutableStateOf(member.unionName) }
    var unionExpanded by remember { mutableStateOf(false) }
    var townVillage by remember { mutableStateOf(member.townVillage) }
    var panchayat by remember { mutableStateOf(member.panchayat) }
    var ward by remember { mutableStateOf(member.ward) }
    var designation by remember { mutableStateOf(member.designation) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("சுயவிவரத்தைத் திருத்து", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it.take(80) },
                    label = { Text("முழுப் பெயர்") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = mobileNumber,
                    onValueChange = { mobileNumber = it.take(20) },
                    label = { Text("கைபேசி எண்") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                ExposedDropdownMenuBox(
                    expanded = unionExpanded,
                    onExpandedChange = { unionExpanded = !unionExpanded }
                ) {
                    OutlinedTextField(
                        value = unionName,
                        onValueChange = { unionName = it.take(60) },
                        label = { Text("ஒன்றியம் / நகரம்") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = unionExpanded)
                        },
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryEditable, enabled = true)
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = unionExpanded,
                        onDismissRequest = { unionExpanded = false }
                    ) {
                        KazhagaConstants.VILLUPURAM_SOUTH_UNIONS.forEach { union ->
                            DropdownMenuItem(
                                text = { Text(union) },
                                onClick = {
                                    unionName = union
                                    unionExpanded = false
                                }
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = townVillage,
                    onValueChange = { townVillage = it.take(60) },
                    label = { Text("ஊர் / கிராமம்") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = panchayat,
                    onValueChange = { panchayat = it.take(60) },
                    label = { Text("ஊராட்சி") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = ward,
                    onValueChange = { ward = it.take(20) },
                    label = { Text("வார்டு எண்") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = designation,
                    onValueChange = { designation = it.take(60) },
                    label = { Text("பொறுப்பு") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(fullName, mobileNumber, unionName, townVillage, panchayat, ward, designation)
                },
                enabled = !isMutating && fullName.trim().length >= 2 && mobileNumber.count { it.isDigit() } >= 10,
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed, contentColor = PureWhite)
            ) {
                Text("சேமி")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("ரத்து") }
        }
    )
}

@Composable
private fun AdminRequestDialog(
    isMutating: Boolean,
    onDismiss: () -> Unit,
    onSubmit: (requestedDesignation: String, reason: String) -> Unit
) {
    var requestedDesignation by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("நிர்வாகி அங்கீகாரக் கோரிக்கை", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "உங்கள் கோரிக்கையை விழுப்புரம் தெற்கு மாவட்ட தலைமை நிர்வாகி மட்டுமே பரிசீலித்து அங்கீகரிக்க முடியும்.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = requestedDesignation,
                    onValueChange = { requestedDesignation = it.take(80) },
                    label = { Text("கோரும் நிர்வாகப் பொறுப்பு *") },
                    placeholder = { Text("எ.கா. ஒன்றிய ஒருங்கிணைப்பாளர்") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it.take(300) },
                    label = { Text("காரணம் / விவரம் *") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(requestedDesignation, reason) },
                enabled = !isMutating && requestedDesignation.trim().length >= 2 && reason.trim().length >= 4,
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed, contentColor = PureWhite)
            ) {
                Text("சமர்ப்பி")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("ரத்து") }
        }
    )
}
