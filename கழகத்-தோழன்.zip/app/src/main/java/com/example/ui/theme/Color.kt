package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Kazhaga Thozhan Signature Red, Black, and White Palette
val CrimsonRed = Color(0xFFC8102E)
val CrimsonRedDark = Color(0xFF96081F)
val CrimsonRedLight = Color(0xFFFFE5E9)
val CrimsonAccent = Color(0xFFE11D48)

val ObsidianBlack = Color(0xFF0D0D0F)
val CharcoalBlack = Color(0xFF18181C)
val GraphiteSurface = Color(0xFF232329)
val SlateBorderDark = Color(0xFF32323B)

val PureWhite = Color(0xFFFFFFFF)
val SoftPaperWhite = Color(0xFFF7F7F8)
val SubtleSurfaceGray = Color(0xFFEEEEF1)
val SubtleBorderLight = Color(0xFFE0E0E5)
val MutedTextLight = Color(0xFF52525B)
val MutedTextDark = Color(0xFFA1A1AA)

val VerifiedGreen = Color(0xFF15803D)
val VerifiedGreenContainer = Color(0xFFDCFCE7)
val WarningAmber = Color(0xFFD97706)
val WarningAmberContainer = Color(0xFFFEF3C7)
val ErrorRed = Color(0xFFDC2626)
val ErrorRedContainer = Color(0xFFFEE2E2)
