package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PriorityHigh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.KazhagaConstants
import com.example.data.model.NotificationItem
import com.example.data.model.UiState
import com.example.data.model.UserMember
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.PureWhite

@Composable
fun NotificationsScreen(
    member: UserMember,
    isApprovedAdmin: Boolean,
    isMutating: Boolean,
    notificationsState: UiState<List<NotificationItem>>,
    onPublishNotification: (
        title: String,
        message: String,
        category: String,
        targetUnion: String,
        authorName: String,
        priority: String
    ) -> Unit,
    onDeleteNotification: (String) -> Unit
) {
    var selectedCategory by remember { mutableStateOf("அனைத்தும்") }
    var showCreateDialog by remember { mutableStateOf(false) }

    val categories = remember { listOf("அனைத்தும்") + KazhagaConstants.NOTIFICATION_CATEGORIES }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize()
        ) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { cat ->
                    val selected = selectedCategory == cat
                    FilterChip(
                        selected = selected,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CrimsonRed,
                            selectedLabelColor = PureWhite
                        )
                    )
                }
            }

            when (notificationsState) {
                is UiState.Loading -> LoadingBox("அறிவிப்புகள் ஏற்றப்படுகின்றன...")
                is UiState.Error -> Box(Modifier.padding(16.dp)) { ErrorBanner(notificationsState.message) }
                is UiState.Success -> {
                    val filtered = if (selectedCategory == "அனைத்தும்") {
                        notificationsState.data
                    } else {
                        notificationsState.data.filter { it.category == selectedCategory }
                    }
                    if (filtered.isEmpty()) {
                        Box(Modifier.padding(16.dp)) {
                            EmptyStateCard(
                                icon = Icons.Default.Campaign,
                                title = "அறிவிப்புகள் இல்லை",
                                subtitle = "தேர்ந்தெடுக்கப்பட்ட பிரிவில் அறிவிப்புகள் எதுவும் இல்லை."
                            )
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 88.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(filtered, key = { it.id }) { notif ->
                                NotificationCard(
                                    item = notif,
                                    canDelete = isApprovedAdmin,
                                    onDelete = { onDeleteNotification(notif.id) }
                                )
                            }
                        }
                    }
                }
            }
        }

        if (isApprovedAdmin) {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                containerColor = CrimsonRed,
                contentColor = PureWhite,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(20.dp)
                    .testTag("fab_publish_notification")
            ) {
                Icon(Icons.Default.Add, contentDescription = "புதிய அறிவிப்பு வெளியிடு")
            }
        }
    }

    if (showCreateDialog) {
        PublishNotificationDialog(
            authorName = member.fullName,
            isMutating = isMutating,
            onDismiss = { showCreateDialog = false },
            onPublish = { title, message, category, union, priority ->
                onPublishNotification(title, message, category, union, member.fullName, priority)
                showCreateDialog = false
            }
        )
    }
}

@Composable
private fun NotificationCard(
    item: NotificationItem,
    canDelete: Boolean,
    onDelete: () -> Unit
) {
    val isHighPriority = item.priority == "high"
    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = if (isHighPriority) CrimsonRed else MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(50.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            if (isHighPriority) {
                                Icon(
                                    imageVector = Icons.Default.PriorityHigh,
                                    contentDescription = null,
                                    tint = PureWhite,
                                    modifier = Modifier.size(13.dp)
                                )
                            }
                            Text(
                                text = item.category,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isHighPriority) PureWhite else MaterialTheme.colorScheme.onSecondaryContainer,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(50.dp)
                    ) {
                        Text(
                            text = item.targetUnion,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                if (canDelete) {
                    IconButton(onClick = onDelete) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "அறிவிப்பை நீக்கு",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }

            Text(
                text = item.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = item.message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "வெளியீடு: ${item.authorName}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = formatTimestampTamil(item.createdAt),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun PublishNotificationDialog(
    authorName: String,
    isMutating: Boolean,
    onDismiss: () -> Unit,
    onPublish: (
        title: String,
        message: String,
        category: String,
        targetUnion: String,
        priority: String
    ) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(KazhagaConstants.NOTIFICATION_CATEGORIES.first()) }
    var targetUnion by remember { mutableStateOf("அனைத்தும்") }
    var isUrgent by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("புதிய மாவட்ட அறிவிப்பு", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it.take(120) },
                    label = { Text("தலைப்பு *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it.take(1500) },
                    label = { Text("அறிவிப்பு விவரம் *") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("பிரிவு:", style = MaterialTheme.typography.labelMedium)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(KazhagaConstants.NOTIFICATION_CATEGORIES) { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CrimsonRed,
                                selectedLabelColor = PureWhite
                            )
                        )
                    }
                }
                OutlinedTextField(
                    value = targetUnion,
                    onValueChange = { targetUnion = it.take(60) },
                    label = { Text("இலக்கு ஒன்றியம் / அனைத்தும்") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("முக்கிய அறிவிப்பு (அவசரம்)", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = isUrgent, onCheckedChange = { isUrgent = it })
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "வெளியிடுபவர்: $authorName",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.trim().length >= 2 && message.trim().length >= 2) {
                        onPublish(
                            title,
                            message,
                            category,
                            targetUnion,
                            if (isUrgent) "high" else "normal"
                        )
                    }
                },
                enabled = !isMutating && title.trim().length >= 2 && message.trim().length >= 2,
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed, contentColor = PureWhite)
            ) {
                Text("வெளியிடு")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("ரத்து") }
        }
    )
}
