package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.DirectoryMember
import com.example.data.model.KazhagaConstants
import com.example.data.model.UiState
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.PureWhite
import com.example.ui.theme.VerifiedGreen

@Composable
fun DirectoryScreen(
    directoryState: UiState<List<DirectoryMember>>
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedUnion by remember { mutableStateOf("அனைத்தும்") }
    val unionFilters = remember { listOf("அனைத்தும்") + KazhagaConstants.VILLUPURAM_SOUTH_UNIONS }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize()
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("பெயர், ஊர், ஊராட்சி அல்லது வார்டு தேடுக...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CrimsonRed,
                    focusedLabelColor = CrimsonRed
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .testTag("directory_search_input")
            )

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(unionFilters) { union ->
                    FilterChip(
                        selected = selectedUnion == union,
                        onClick = { selectedUnion = union },
                        label = { Text(union) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CrimsonRed,
                            selectedLabelColor = PureWhite
                        )
                    )
                }
            }

            when (directoryState) {
                is UiState.Loading -> LoadingBox("உறுப்பினர் பட்டியல் ஏற்றப்படுகிறது...")
                is UiState.Error -> Box(Modifier.padding(16.dp)) { ErrorBanner(directoryState.message) }
                is UiState.Success -> {
                    val q = searchQuery.trim()
                    val filtered = directoryState.data.filter { member ->
                        val unionMatch = selectedUnion == "அனைத்தும்" || member.unionName == selectedUnion
                        val queryMatch = q.isBlank() ||
                            member.fullName.contains(q, ignoreCase = true) ||
                            member.townVillage.contains(q, ignoreCase = true) ||
                            member.panchayat.contains(q, ignoreCase = true) ||
                            member.unionName.contains(q, ignoreCase = true) ||
                            member.ward.contains(q, ignoreCase = true)
                        unionMatch && queryMatch
                    }

                    if (filtered.isEmpty()) {
                        Box(Modifier.padding(16.dp)) {
                            EmptyStateCard(
                                icon = Icons.Default.Groups,
                                title = "உறுப்பினர்கள் கிடைக்கவில்லை",
                                subtitle = "தேடல் வார்த்தை அல்லது ஒன்றியத்தை மாற்றி முயற்சிக்கவும்."
                            )
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(filtered, key = { it.userId }) { item ->
                                DirectoryMemberCard(item)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DirectoryMemberCard(member: DirectoryMember) {
    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(CrimsonRed.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = member.fullName.trim().take(1).ifBlank { "த" },
                    style = MaterialTheme.typography.titleLarge,
                    color = CrimsonRed,
                    fontWeight = FontWeight.Bold
                )
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = member.fullName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (member.verified) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = "சரிபார்க்கப்பட்டது",
                            tint = VerifiedGreen,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Text(
                    text = member.designation.ifBlank { "உறுப்பினர்" },
                    style = MaterialTheme.typography.bodySmall,
                    color = CrimsonRed,
                    fontWeight = FontWeight.SemiBold
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "${member.unionName} • ${member.townVillage} • ${member.panchayat} (வார்டு ${member.ward})",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
