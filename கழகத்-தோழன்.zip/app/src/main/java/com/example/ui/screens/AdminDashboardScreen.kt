package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AdminRecord
import com.example.data.model.AdminRequest
import com.example.data.model.KazhagaConstants
import com.example.data.model.UiState
import com.example.data.model.UserMember
import com.example.data.model.roleDisplayTamil
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.VerifiedGreen

@Composable
fun AdminDashboardScreen(
    currentMember: UserMember,
    isChiefAdmin: Boolean,
    ownAdminRecord: AdminRecord?,
    allMembersState: UiState<List<UserMember>>,
    allAdminsState: UiState<List<AdminRecord>>,
    adminRequestsState: UiState<List<AdminRequest>>,
    isMutating: Boolean,
    onBootstrapChiefAdmin: (UserMember) -> Unit,
    onVerifyMember: (memberUid: String, verified: Boolean, status: String) -> Unit,
    onPromoteToAdmin: (targetMember: UserMember, unionScope: String, hasPendingRequest: Boolean) -> Unit,
    onApproveAdminRequest: (AdminRequest) -> Unit,
    onRejectAdminRequest: (userId: String) -> Unit,
    onSetAdminApproval: (AdminRecord, Boolean) -> Unit
) {
    var selectedSubTab by remember { mutableIntStateOf(0) }
    var memberSearch by remember { mutableStateOf("") }
    var promoteTarget by remember { mutableStateOf<UserMember?>(null) }

    val pendingRequests = (adminRequestsState as? UiState.Success)?.data
        ?.filter { it.status == KazhagaConstants.STATUS_PENDING }.orEmpty()
    val pendingRequestUids = remember(pendingRequests) { pendingRequests.map { it.userId }.toSet() }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxSize()
        ) {
            // Server-verified Authority Banner
            Surface(
                color = ObsidianBlack,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.GppGood,
                            contentDescription = null,
                            tint = CrimsonRed
                        )
                        Column {
                            Text(
                                text = if (isChiefAdmin) {
                                    "மாவட்ட தலைமை நிர்வாகி கட்டுப்பாட்டகம்"
                                } else {
                                    "மாவட்ட நிர்வாகி கட்டுப்பாட்டகம்"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = PureWhite,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isChiefAdmin) {
                                    "முழு அதிகாரம்: நிர்வாகிகளை உருவாக்க & அங்கீகரிக்க முடியும்"
                                } else {
                                    "உறுப்பினர் சரிபார்ப்பு & அறிவிப்பு வெளியீடு மட்டும்"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = PureWhite.copy(alpha = 0.78f)
                            )
                        }
                    }

                    if (isChiefAdmin && ownAdminRecord == null) {
                        Button(
                            onClick = { onBootstrapChiefAdmin(currentMember) },
                            enabled = !isMutating,
                            colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed, contentColor = PureWhite),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("பதிவு இயக்கு", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            TabRow(
                selectedTabIndex = selectedSubTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = CrimsonRed,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedSubTab]),
                        color = CrimsonRed
                    )
                }
            ) {
                Tab(
                    selected = selectedSubTab == 0,
                    onClick = { selectedSubTab = 0 },
                    text = { Text("உறுப்பினர்கள்", fontWeight = FontWeight.SemiBold) }
                )
                Tab(
                    selected = selectedSubTab == 1,
                    onClick = { selectedSubTab = 1 },
                    text = {
                        val badge = if (isChiefAdmin && pendingRequests.isNotEmpty()) {
                            " (${pendingRequests.size})"
                        } else ""
                        Text("நிர்வாகிகள்$badge", fontWeight = FontWeight.SemiBold)
                    }
                )
            }

            if (selectedSubTab == 0) {
                OutlinedTextField(
                    value = memberSearch,
                    onValueChange = { memberSearch = it },
                    placeholder = { Text("உறுப்பினர் பெயர், கைபேசி, ஒன்றியம் தேடுக...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                )

                when (allMembersState) {
                    is UiState.Loading -> LoadingBox("உறுப்பினர்கள் ஏற்றப்படுகிறார்கள்...")
                    is UiState.Error -> Box(Modifier.padding(16.dp)) { ErrorBanner(allMembersState.message) }
                    is UiState.Success -> {
                        val q = memberSearch.trim()
                        val filtered = allMembersState.data.filter { m ->
                            q.isBlank() ||
                                m.fullName.contains(q, ignoreCase = true) ||
                                m.mobileNumber.contains(q, ignoreCase = true) ||
                                m.unionName.contains(q, ignoreCase = true) ||
                                m.panchayat.contains(q, ignoreCase = true)
                        }
                        if (filtered.isEmpty()) {
                            Box(Modifier.padding(16.dp)) {
                                EmptyStateCard(
                                    icon = Icons.Default.AdminPanelSettings,
                                    title = "உறுப்பினர்கள் இல்லை",
                                    subtitle = "பதிவு செய்யப்பட்ட உறுப்பினர்கள் இங்கே தோன்றுவார்கள்."
                                )
                            }
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(filtered, key = { it.userId }) { member ->
                                    AdminMemberManageCard(
                                        member = member,
                                        isChiefAdmin = isChiefAdmin,
                                        isMutating = isMutating,
                                        onToggleVerify = {
                                            onVerifyMember(
                                                member.userId,
                                                !member.verified,
                                                KazhagaConstants.STATUS_ACTIVE
                                            )
                                        },
                                        onAppointAdmin = { promoteTarget = member }
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (!isChiefAdmin) {
                        item {
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = MaterialTheme.shapes.medium,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = null,
                                        tint = CrimsonRed
                                    )
                                    Text(
                                        text = "விழுப்புரம் தெற்கு மாவட்ட தலைமை நிர்வாகி மட்டுமே புதிய நிர்வாகி கணக்குகளை உருவாக்கவும் அங்கீகரிக்கவும் முடியும். பிற நிர்வாகிகள் புதிய நிர்வாகிகளைச் சேர்க்க இயலாது.",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    } else if (pendingRequests.isNotEmpty()) {
                        item {
                            Text(
                                text = "நிர்வாகி அங்கீகாரக் கோரிக்கைகள் (${pendingRequests.size})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        items(pendingRequests, key = { it.userId }) { req ->
                            AdminRequestReviewCard(
                                request = req,
                                isMutating = isMutating,
                                onApprove = { onApproveAdminRequest(req) },
                                onReject = { onRejectAdminRequest(req.userId) }
                            )
                        }
                    }

                    item {
                        Text(
                            text = "அங்கீகரிக்கப்பட்ட நிர்வாகிகள்",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    when (allAdminsState) {
                        is UiState.Loading -> item { LoadingBox("நிர்வாகிகள் பட்டியல் ஏற்றப்படுகிறது...") }
                        is UiState.Error -> item { ErrorBanner(allAdminsState.message) }
                        is UiState.Success -> {
                            if (allAdminsState.data.isEmpty()) {
                                item {
                                    EmptyStateCard(
                                        icon = Icons.Default.AdminPanelSettings,
                                        title = "நிர்வாகி பதிவுகள் இல்லை",
                                        subtitle = "உறுப்பினர்கள் தாவலில் இருந்து நிர்வாகிகளை நியமிக்கலாம்."
                                    )
                                }
                            } else {
                                items(allAdminsState.data, key = { it.uid }) { admin ->
                                    AdminRecordCard(
                                        admin = admin,
                                        isChiefAdmin = isChiefAdmin,
                                        isSelf = admin.uid == currentMember.userId,
                                        isMutating = isMutating,
                                        onToggleApproval = {
                                            onSetAdminApproval(admin, !admin.approved)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    promoteTarget?.let { target ->
        PromoteAdminDialog(
            member = target,
            isMutating = isMutating,
            onDismiss = { promoteTarget = null },
            onConfirm = { unionScope ->
                onPromoteToAdmin(target, unionScope, pendingRequestUids.contains(target.userId))
                promoteTarget = null
            }
        )
    }
}

@Composable
private fun AdminMemberManageCard(
    member: UserMember,
    isChiefAdmin: Boolean,
    isMutating: Boolean,
    onToggleVerify: () -> Unit,
    onAppointAdmin: () -> Unit
) {
    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = member.fullName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        if (member.verified) {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = "சரிபார்க்கப்பட்டது",
                                tint = VerifiedGreen,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Text(
                        text = "${member.mobileNumber} • ${member.unionName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${member.townVillage}, ${member.panchayat} (வார்டு ${member.ward})",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    color = if (member.role == KazhagaConstants.ROLE_MEMBER) {
                        MaterialTheme.colorScheme.secondaryContainer
                    } else {
                        CrimsonRed
                    },
                    shape = RoundedCornerShape(50.dp)
                ) {
                    Text(
                        text = roleDisplayTamil(member.role),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (member.role == KazhagaConstants.ROLE_MEMBER) {
                            MaterialTheme.colorScheme.onSecondaryContainer
                        } else {
                            PureWhite
                        },
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onToggleVerify,
                    enabled = !isMutating,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (member.verified) "சரிபார்ப்பை நீக்கு" else "சரிபார்க்கவும்",
                        style = MaterialTheme.typography.labelMedium
                    )
                }

                if (isChiefAdmin && member.role == KazhagaConstants.ROLE_MEMBER) {
                    Button(
                        onClick = onAppointAdmin,
                        enabled = !isMutating,
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed, contentColor = PureWhite),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("appoint_admin_${member.userId}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PersonAdd,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("நிர்வாகியாக்கு", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminRequestReviewCard(
    request: AdminRequest,
    isMutating: Boolean,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = request.fullName,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "${request.mobileNumber} • ${request.unionName}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "கோரும் பொறுப்பு: ${request.requestedDesignation}",
                style = MaterialTheme.typography.bodySmall,
                color = CrimsonRed,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = request.reason,
                style = MaterialTheme.typography.bodySmall
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onReject,
                    enabled = !isMutating,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("நிராகரி")
                }
                Button(
                    onClick = onApprove,
                    enabled = !isMutating,
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed, contentColor = PureWhite),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("அங்கீகரி")
                }
            }
        }
    }
}

@Composable
private fun AdminRecordCard(
    admin: AdminRecord,
    isChiefAdmin: Boolean,
    isSelf: Boolean,
    isMutating: Boolean,
    onToggleApproval: () -> Unit
) {
    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = admin.fullName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${roleDisplayTamil(admin.adminLevel)} • ${admin.unionScope}",
                    style = MaterialTheme.typography.bodySmall,
                    color = CrimsonRed
                )
                Text(
                    text = admin.mobileNumber,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (isChiefAdmin && !isSelf && admin.adminLevel != KazhagaConstants.ROLE_CHIEF_ADMIN) {
                OutlinedButton(
                    onClick = onToggleApproval,
                    enabled = !isMutating
                ) {
                    Text(if (admin.approved) "நீக்கு" else "மீண்டும் அங்கீகரி")
                }
            } else {
                Surface(
                    color = if (admin.approved) VerifiedGreen.copy(alpha = 0.14f) else MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(50.dp)
                ) {
                    Text(
                        text = if (admin.approved) "அங்கீகரிக்கப்பட்டது" else "நிறுத்தப்பட்டது",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (admin.approved) VerifiedGreen else MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PromoteAdminDialog(
    member: UserMember,
    isMutating: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (unionScope: String) -> Unit
) {
    var unionScope by remember { mutableStateOf(member.unionName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("நிர்வாகியாக நியமிக்கவும்", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "${member.fullName} அவர்களை விழுப்புரம் தெற்கு மாவட்ட நிர்வாகியாக அங்கீகரிக்கிறீர்களா?",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedTextField(
                    value = unionScope,
                    onValueChange = { unionScope = it.take(60) },
                    label = { Text("நிர்வாகப் பகுதி / ஒன்றியம் *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(unionScope) },
                enabled = !isMutating && unionScope.trim().length >= 2,
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed, contentColor = PureWhite)
            ) {
                Text("அங்கீகரி")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("ரத்து") }
        }
    )
}
