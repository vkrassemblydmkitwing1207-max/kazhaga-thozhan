package com.example.ui.auth

import android.app.Activity
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Firebase
import com.google.firebase.FirebaseException
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthMissingActivityForRecaptchaException
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit

data class PhoneAuthUiState(
    val phoneDigits: String = "",
    val otpCode: String = "",
    val verificationId: String? = null,
    val resendToken: PhoneAuthProvider.ForceResendingToken? = null,
    val resendCooldownSeconds: Int = 0,
    val isOtpScreenVisible: Boolean = false,
    val isSendingOtp: Boolean = false,
    val isVerifyingOtp: Boolean = false,
    val isGoogleLoading: Boolean = false,
    val errorMessage: String? = null,
    val infoMessage: String? = null
)

object IndianPhoneValidator {
    private val INDIAN_MOBILE_REGEX = Regex("^[6-9]\\d{9}$")

    fun normalizeInput(rawInput: String): String {
        val digitsOnly = rawInput.filter { it.isDigit() }
        return when {
            digitsOnly.length == 12 && digitsOnly.startsWith("91") -> digitsOnly.drop(2)
            digitsOnly.length == 11 && digitsOnly.startsWith("0") -> digitsOnly.drop(1)
            else -> digitsOnly.take(10)
        }
    }

    fun isValid(digits: String): Boolean = INDIAN_MOBILE_REGEX.matches(digits)

    fun validationErrorTamil(digits: String): String? {
        if (digits.isEmpty()) return "10 இலக்க கைபேசி எண்ணை உள்ளிடவும்."
        if (digits.length < 10) return "கைபேசி எண் 10 இலக்கங்களாக இருக்க வேண்டும்."
        if (digits.first() !in '6'..'9') {
            return "இந்திய கைபேசி எண் 6, 7, 8 அல்லது 9-இல் தொடங்க வேண்டும்."
        }
        return null
    }

    fun toE164(digits: String): String = "+91$digits"
}

class AuthViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(PhoneAuthUiState())
    val uiState: StateFlow<PhoneAuthUiState> = _uiState.asStateFlow()

    private var cooldownJob: Job? = null

    fun onPhoneDigitsChanged(rawInput: String) {
        val normalized = IndianPhoneValidator.normalizeInput(rawInput)
        _uiState.update {
            it.copy(
                phoneDigits = normalized,
                errorMessage = null
            )
        }
    }

    fun onOtpCodeChanged(rawInput: String) {
        val digits = rawInput.filter { it.isDigit() }.take(6)
        _uiState.update {
            it.copy(
                otpCode = digits,
                errorMessage = null
            )
        }
    }

    fun setGoogleLoading(loading: Boolean) {
        _uiState.update { it.copy(isGoogleLoading = loading, errorMessage = null) }
    }

    fun setError(message: String?) {
        _uiState.update { it.copy(errorMessage = message) }
    }

    fun goBackToPhoneEntry() {
        cooldownJob?.cancel()
        _uiState.update {
            it.copy(
                isOtpScreenVisible = false,
                otpCode = "",
                verificationId = null,
                resendCooldownSeconds = 0,
                isSendingOtp = false,
                isVerifyingOtp = false,
                errorMessage = null,
                infoMessage = null
            )
        }
    }

    fun sendOtp(
        activity: Activity?,
        isResend: Boolean = false,
        onAutoVerified: () -> Unit
    ) {
        val currentDigits = _uiState.value.phoneDigits
        val validationError = IndianPhoneValidator.validationErrorTamil(currentDigits)
        if (validationError != null) {
            _uiState.update { it.copy(errorMessage = validationError, infoMessage = null) }
            return
        }
        if (activity == null) {
            _uiState.update {
                it.copy(
                    errorMessage = "கைபேசி சரிபார்ப்பிற்கு Activity சூழல் கிடைக்கவில்லை.",
                    infoMessage = null
                )
            }
            return
        }
        if (isResend && _uiState.value.resendCooldownSeconds > 0) {
            return
        }

        val e164Phone = IndianPhoneValidator.toE164(currentDigits)
        Firebase.auth.setLanguageCode("ta")

        _uiState.update {
            it.copy(
                isSendingOtp = true,
                errorMessage = null,
                infoMessage = if (isResend) "புதிய OTP அனுப்பப்படுகிறது..." else "OTP அனுப்பப்படுகிறது..."
            )
        }

        val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                Log.i(TAG, "Phone auto-verification completed")
                signInWithPhoneCredential(credential, onAutoVerified)
            }

            override fun onVerificationFailed(e: FirebaseException) {
                Log.w(TAG, "Phone verification failed", e)
                _uiState.update {
                    it.copy(
                        isSendingOtp = false,
                        isVerifyingOtp = false,
                        infoMessage = null,
                        errorMessage = mapPhoneAuthError(e)
                    )
                }
            }

            override fun onCodeSent(
                verificationId: String,
                token: PhoneAuthProvider.ForceResendingToken
            ) {
                Log.i(TAG, "OTP code sent to $e164Phone")
                _uiState.update {
                    it.copy(
                        verificationId = verificationId,
                        resendToken = token,
                        otpCode = if (isResend) "" else it.otpCode,
                        isOtpScreenVisible = true,
                        isSendingOtp = false,
                        errorMessage = null,
                        infoMessage = "+91 $currentDigits எண்ணிற்கு 6 இலக்க OTP அனுப்பப்பட்டது."
                    )
                }
                startResendCooldown()
            }

            override fun onCodeAutoRetrievalTimeOut(verificationId: String) {
                Log.i(TAG, "OTP auto-retrieval timed out; manual entry remains active")
                _uiState.update { it.copy(verificationId = verificationId) }
            }
        }

        val optionsBuilder = PhoneAuthOptions.newBuilder(Firebase.auth)
            .setPhoneNumber(e164Phone)
            .setTimeout(RESEND_TIMEOUT_SECONDS, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(callbacks)

        val token = _uiState.value.resendToken
        if (isResend && token != null) {
            optionsBuilder.setForceResendingToken(token)
        }

        try {
            PhoneAuthProvider.verifyPhoneNumber(optionsBuilder.build())
        } catch (e: Exception) {
            Log.e(TAG, "verifyPhoneNumber threw exception", e)
            _uiState.update {
                it.copy(
                    isSendingOtp = false,
                    infoMessage = null,
                    errorMessage = mapPhoneAuthError(e)
                )
            }
        }
    }

    fun verifyOtp(onAuthSuccess: () -> Unit) {
        val state = _uiState.value
        val vId = state.verificationId
        if (vId.isNullOrBlank()) {
            _uiState.update {
                it.copy(errorMessage = "OTP அமர்வு கிடைக்கவில்லை. மீண்டும் OTP பெறவும்.")
            }
            return
        }
        val code = state.otpCode.filter { it.isDigit() }
        if (code.length != 6) {
            _uiState.update {
                it.copy(errorMessage = "6 இலக்க OTP குறியீட்டை முழுமையாக உள்ளிடவும்.")
            }
            return
        }

        val credential = PhoneAuthProvider.getCredential(vId, code)
        signInWithPhoneCredential(credential, onAuthSuccess)
    }

    private fun signInWithPhoneCredential(
        credential: PhoneAuthCredential,
        onAuthSuccess: () -> Unit
    ) {
        _uiState.update {
            it.copy(
                isSendingOtp = false,
                isVerifyingOtp = true,
                errorMessage = null
            )
        }
        viewModelScope.launch {
            try {
                Firebase.auth.signInWithCredential(credential).await()
                cooldownJob?.cancel()
                _uiState.update {
                    it.copy(
                        isVerifyingOtp = false,
                        errorMessage = null
                    )
                }
                onAuthSuccess()
            } catch (e: Exception) {
                Log.w(TAG, "signInWithCredential failed", e)
                _uiState.update {
                    it.copy(
                        isVerifyingOtp = false,
                        errorMessage = mapPhoneAuthError(e)
                    )
                }
            }
        }
    }

    private fun startResendCooldown() {
        cooldownJob?.cancel()
        cooldownJob = viewModelScope.launch {
            for (seconds in RESEND_TIMEOUT_SECONDS.toInt() downTo 1) {
                _uiState.update { it.copy(resendCooldownSeconds = seconds) }
                delay(1000L)
            }
            _uiState.update { it.copy(resendCooldownSeconds = 0) }
        }
    }

    private fun mapPhoneAuthError(e: Exception): String {
        val authErrorCode = (e as? FirebaseAuthException)?.errorCode
        return when {
            e is FirebaseNetworkException ||
                e.message?.contains("network", ignoreCase = true) == true ->
                "இணைய இணைப்பு இல்லை. உங்கள் நெட்வொர்க்கைச் சரிபார்த்து மீண்டும் முயற்சிக்கவும்."

            e is FirebaseTooManyRequestsException ||
                authErrorCode == "ERROR_TOO_MANY_REQUESTS" ||
                e.message?.contains("TOO_MANY_REQUESTS", ignoreCase = true) == true ->
                "அதிக OTP முயற்சிகள் செய்யப்பட்டுள்ளன. சிறிது நேரம் கழித்து மீண்டும் முயற்சிக்கவும்."

            e is FirebaseAuthMissingActivityForRecaptchaException ->
                "reCAPTCHA சரிபார்ப்பிற்கு Activity சாளரம் தேவை."

            authErrorCode == "ERROR_INVALID_VERIFICATION_CODE" ->
                "நீங்கள் உள்ளிட்ட OTP குறியீடு தவறானது. SMS-இல் வந்த 6 இலக்க எண்ணைச் சரிபார்க்கவும்."

            authErrorCode == "ERROR_SESSION_EXPIRED" ->
                "OTP காலாவதியாகிவிட்டது. 'OTP மீண்டும் அனுப்பு' என்பதைத் தட்டவும்."

            authErrorCode == "ERROR_INVALID_PHONE_NUMBER" ||
                (e is FirebaseAuthInvalidCredentialsException &&
                    e.message?.contains("phone", ignoreCase = true) == true) ->
                "சரியான இந்திய 10 இலக்க கைபேசி எண்ணை (+91) உள்ளிடவும்."

            e is FirebaseAuthInvalidCredentialsException ->
                "தவறான OTP அல்லது சான்று. மீண்டும் சரிபார்க்கவும்."

            authErrorCode == "ERROR_OPERATION_NOT_ALLOWED" ||
                e.message?.contains("OPERATION_NOT_ALLOWED", ignoreCase = true) == true ->
                "Firebase Console-இல் Phone Authentication இன்னும் இயக்கப்படவில்லை. Authentication → Sign-in method → Phone என்பதை Enable செய்யவும், அல்லது Google மூலம் உள்நுழையவும்."

            authErrorCode == "ERROR_APP_NOT_AUTHORIZED" ||
                e.message?.contains("APP_NOT_AUTHORIZED", ignoreCase = true) == true ->
                "இந்தச் செயலியின் SHA-1 / SHA-256 சான்றிதழ் Firebase-இல் அங்கீகரிக்கப்படவில்லை."

            e.message?.contains("BILLING_NOT_ENABLED", ignoreCase = true) == true ->
                "Firebase Console-இல் சோதனை எண் (Test Phone Number) அல்லது SMS திட்டத்தை அமைக்கவும்."

            else ->
                "சரிபார்ப்புப் பிழை: ${e.localizedMessage ?: "மீண்டும் முயற்சிக்கவும்."}"
        }
    }

    override fun onCleared() {
        super.onCleared()
        cooldownJob?.cancel()
    }

    private companion object {
        const val TAG = "KazhagaPhoneAuth"
        const val RESEND_TIMEOUT_SECONDS = 60L
    }
}
