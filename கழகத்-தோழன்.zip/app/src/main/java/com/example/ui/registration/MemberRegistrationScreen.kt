package com.example.ui.registration

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.KazhagaConstants
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PureWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemberRegistrationScreen(
    initialFullName: String,
    initialPhoneNumber: String,
    isSubmitting: Boolean,
    errorMessage: String?,
    onSubmit: (
        fullName: String,
        mobileNumber: String,
        unionName: String,
        townVillage: String,
        panchayat: String,
        ward: String,
        designation: String
    ) -> Unit,
    onSignOut: () -> Unit
) {
    var fullName by remember { mutableStateOf(initialFullName) }
    var mobileNumber by remember { mutableStateOf(initialPhoneNumber) }
    var unionName by remember { mutableStateOf(KazhagaConstants.VILLUPURAM_SOUTH_UNIONS.first()) }
    var unionExpanded by remember { mutableStateOf(false) }
    var townVillage by remember { mutableStateOf("") }
    var panchayat by remember { mutableStateOf("") }
    var ward by remember { mutableStateOf("") }
    var designation by remember { mutableStateOf("உறுப்பினர்") }
    var validationError by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "உறுப்பினர் பதிவு",
                            style = MaterialTheme.typography.titleLarge,
                            color = PureWhite
                        )
                        Text(
                            text = "${KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH} மாவட்டம்",
                            style = MaterialTheme.typography.bodySmall,
                            color = PureWhite.copy(alpha = 0.8f)
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = onSignOut,
                        modifier = Modifier.testTag("registration_logout_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Logout,
                            contentDescription = "வெளியேறு",
                            tint = PureWhite
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ObsidianBlack,
                    titleContentColor = PureWhite
                ),
                modifier = Modifier.statusBarsPadding()
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .navigationBarsPadding()
                .imePadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 600.dp)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Surface(
                    color = CrimsonRed,
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PersonAdd,
                            contentDescription = null,
                            tint = PureWhite,
                            modifier = Modifier.size(30.dp)
                        )
                        Column {
                            Text(
                                text = "கழகத் தோழன் உறுப்பினர் படிவம்",
                                style = MaterialTheme.typography.titleMedium,
                                color = PureWhite,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "தொடர உங்கள் விழுப்புரம் தெற்கு மாவட்ட விவரங்களைப் பதிவு செய்யவும்.",
                                style = MaterialTheme.typography.bodySmall,
                                color = PureWhite.copy(alpha = 0.9f)
                            )
                        }
                    }
                }

                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        val fieldColors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CrimsonRed,
                            focusedLabelColor = CrimsonRed
                        )

                        OutlinedTextField(
                            value = fullName,
                            onValueChange = { fullName = it.take(80) },
                            label = { Text("முழுப் பெயர் *") },
                            placeholder = { Text("எ.கா. தமிழ்மாறன் க") },
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("reg_full_name")
                        )

                        val isPhoneVerifiedFromAuth = initialPhoneNumber.isNotBlank()
                        OutlinedTextField(
                            value = mobileNumber,
                            onValueChange = { if (!isPhoneVerifiedFromAuth) mobileNumber = it.take(20) },
                            readOnly = isPhoneVerifiedFromAuth,
                            label = { Text("கைபேசி எண் *") },
                            placeholder = { Text("+919876543210") },
                            leadingIcon = {
                                Icon(Icons.Default.Phone, contentDescription = null)
                            },
                            supportingText = {
                                if (isPhoneVerifiedFromAuth) {
                                    Text("OTP மூலம் சரிபார்க்கப்பட்ட கைபேசி எண்")
                                }
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("reg_mobile_number")
                        )

                        OutlinedTextField(
                            value = KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("மாவட்டம்") },
                            leadingIcon = {
                                Icon(Icons.Default.LocationCity, contentDescription = null, tint = CrimsonRed)
                            },
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )

                        ExposedDropdownMenuBox(
                            expanded = unionExpanded,
                            onExpandedChange = { unionExpanded = !unionExpanded }
                        ) {
                            OutlinedTextField(
                                value = unionName,
                                onValueChange = { unionName = it.take(60) },
                                label = { Text("ஒன்றியம் / நகரம் *") },
                                trailingIcon = {
                                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = unionExpanded)
                                },
                                colors = fieldColors,
                                modifier = Modifier
                                    .menuAnchor(MenuAnchorType.PrimaryEditable, enabled = true)
                                    .fillMaxWidth()
                                    .testTag("reg_union_name")
                            )
                            ExposedDropdownMenu(
                                expanded = unionExpanded,
                                onDismissRequest = { unionExpanded = false }
                            ) {
                                KazhagaConstants.VILLUPURAM_SOUTH_UNIONS.forEach { union ->
                                    DropdownMenuItem(
                                        text = { Text(union) },
                                        onClick = {
                                            unionName = union
                                            unionExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = townVillage,
                            onValueChange = { townVillage = it.take(60) },
                            label = { Text("ஊர் / கிராமம் *") },
                            placeholder = { Text("எ.கா. திருவாமாத்தூர்") },
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("reg_town_village")
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedTextField(
                                value = panchayat,
                                onValueChange = { panchayat = it.take(60) },
                                label = { Text("ஊராட்சி *") },
                                placeholder = { Text("ஊராட்சிப் பெயர்") },
                                singleLine = true,
                                colors = fieldColors,
                                modifier = Modifier
                                    .weight(1.4f)
                                    .testTag("reg_panchayat")
                            )

                            OutlinedTextField(
                                value = ward,
                                onValueChange = { ward = it.take(20) },
                                label = { Text("வார்டு *") },
                                placeholder = { Text("எ.கா. 4") },
                                singleLine = true,
                                colors = fieldColors,
                                modifier = Modifier
                                    .weight(0.8f)
                                    .testTag("reg_ward")
                            )
                        }

                        OutlinedTextField(
                            value = designation,
                            onValueChange = { designation = it.take(60) },
                            label = { Text("கழகப் பொறுப்பு (விருப்பம்)") },
                            placeholder = { Text("உறுப்பினர் / கிளைச் செயலாளர்") },
                            leadingIcon = {
                                Icon(Icons.Default.Badge, contentDescription = null)
                            },
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("reg_designation")
                        )

                        val displayedError = validationError ?: errorMessage
                        if (displayedError != null) {
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = displayedError,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }

                        Button(
                            onClick = {
                                validationError = validateForm(
                                    fullName, mobileNumber, unionName, townVillage, panchayat, ward
                                )
                                if (validationError == null) {
                                    onSubmit(
                                        fullName,
                                        mobileNumber,
                                        unionName,
                                        townVillage,
                                        panchayat,
                                        ward,
                                        designation
                                    )
                                }
                            },
                            enabled = !isSubmitting,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CrimsonRed,
                                contentColor = PureWhite
                            ),
                            shape = MaterialTheme.shapes.medium,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("reg_submit_button")
                        ) {
                            if (isSubmitting) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    color = PureWhite,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Text(
                                    text = "பதிவைச் சமர்ப்பிக்கவும்",
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun validateForm(
    fullName: String,
    mobileNumber: String,
    unionName: String,
    townVillage: String,
    panchayat: String,
    ward: String
): String? {
    if (fullName.trim().length < 2) return "முழுப் பெயரை உள்ளிடவும் (குறைந்தது 2 எழுத்துக்கள்)."
    val digitsCount = mobileNumber.count { it.isDigit() }
    if (digitsCount < 10) return "சரியான 10 இலக்க கைபேசி எண்ணை உள்ளிடவும்."
    if (unionName.trim().length < 2) return "ஒன்றியம் / நகரம் பெயரை உள்ளிடவும்."
    if (townVillage.trim().length < 2) return "ஊர் / கிராமம் பெயரை உள்ளிடவும்."
    if (panchayat.trim().isEmpty()) return "ஊராட்சி பெயரை உள்ளிடவும்."
    if (ward.trim().isEmpty()) return "வார்டு எண்ணை உள்ளிடவும்."
    return null
}
