package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.AdminRecord
import com.example.data.model.AdminRequest
import com.example.data.model.DirectoryMember
import com.example.data.model.KazhagaConstants
import com.example.data.model.NotificationItem
import com.example.data.model.UserMember
import com.example.data.remote.OperationType
import com.example.data.remote.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class KazhagaRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        val uid = auth.currentUser?.uid
        if (uid.isNullOrBlank()) {
            throw IllegalStateException("பயனர் உள்நுழைவு அவசியம்.")
        }
        return uid
    }

    fun observeCurrentUserProfile(uid: String): Flow<UserMember?> = flow {
        if (uid.isBlank()) {
            emit(null)
            return@flow
        }
        val path = "users/$uid"
        emitAll(
            db.collection("users").document(uid)
                .snapshots()
                .map { snapshot ->
                    if (!snapshot.exists()) null
                    else snapshot.toObject(
                        UserMember::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    logStreamError(error, OperationType.GET, path, uid)
                    throw error
                }
        )
    }

    fun observeAdminRecord(uid: String): Flow<AdminRecord?> = flow {
        if (uid.isBlank()) {
            emit(null)
            return@flow
        }
        val path = "admins/$uid"
        emitAll(
            db.collection("admins").document(uid)
                .snapshots()
                .map { snapshot ->
                    if (!snapshot.exists()) null
                    else snapshot.toObject(
                        AdminRecord::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    logStreamError(error, OperationType.GET, path, uid)
                    throw error
                }
        )
    }

    fun observeOwnAdminRequest(uid: String): Flow<AdminRequest?> = flow {
        if (uid.isBlank()) {
            emit(null)
            return@flow
        }
        val path = "admin_requests/$uid"
        emitAll(
            db.collection("admin_requests").document(uid)
                .snapshots()
                .map { snapshot ->
                    if (!snapshot.exists()) null
                    else snapshot.toObject(
                        AdminRequest::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    logStreamError(error, OperationType.GET, path, uid)
                    throw error
                }
        )
    }

    fun observeNotifications(uid: String): Flow<List<NotificationItem>> = flow {
        if (uid.isBlank()) {
            emit(emptyList())
            return@flow
        }
        val path = "notifications"
        emitAll(
            db.collection("notifications")
                .whereEqualTo("district", KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        NotificationItem::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    fun observeDirectory(uid: String): Flow<List<DirectoryMember>> = flow {
        if (uid.isBlank()) {
            emit(emptyList())
            return@flow
        }
        val path = "directory"
        emitAll(
            db.collection("directory")
                .whereEqualTo("district", KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        DirectoryMember::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedBy { it.fullName }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    fun observeAllUsersForAdmin(uid: String): Flow<List<UserMember>> = flow {
        if (uid.isBlank()) {
            emit(emptyList())
            return@flow
        }
        val path = "users"
        emitAll(
            db.collection("users")
                .whereEqualTo("district", KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        UserMember::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    fun observeAllAdmins(uid: String): Flow<List<AdminRecord>> = flow {
        if (uid.isBlank()) {
            emit(emptyList())
            return@flow
        }
        val path = "admins"
        emitAll(
            db.collection("admins")
                .whereEqualTo("district", KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        AdminRecord::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    fun observeAdminRequestsForChief(uid: String): Flow<List<AdminRequest>> = flow {
        if (uid.isBlank()) {
            emit(emptyList())
            return@flow
        }
        val path = "admin_requests"
        emitAll(
            db.collection("admin_requests")
                .whereEqualTo("district", KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        AdminRequest::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    suspend fun registerMember(
        fullName: String,
        mobileNumber: String,
        unionName: String,
        townVillage: String,
        panchayat: String,
        ward: String,
        designation: String
    ): Result<Unit> {
        val currentUid = auth.currentUser?.uid ?: "unauthenticated"
        val userPath = "users/$currentUid"
        return try {
            val uid = requireUserId()
            validateMemberInputs(fullName, mobileNumber, unionName, townVillage, panchayat, ward, designation)

            val cleanDesignation = designation.trim().ifBlank { "உறுப்பினர்" }
            val userPayload = mapOf(
                "userId" to uid,
                "fullName" to fullName.trim(),
                "mobileNumber" to mobileNumber.trim(),
                "district" to KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH,
                "unionName" to unionName.trim(),
                "townVillage" to townVillage.trim(),
                "panchayat" to panchayat.trim(),
                "ward" to ward.trim(),
                "designation" to cleanDesignation,
                "role" to KazhagaConstants.ROLE_MEMBER,
                "memberStatus" to KazhagaConstants.STATUS_ACTIVE,
                "verified" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            val directoryPayload = mapOf(
                "userId" to uid,
                "fullName" to fullName.trim(),
                "district" to KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH,
                "unionName" to unionName.trim(),
                "townVillage" to townVillage.trim(),
                "panchayat" to panchayat.trim(),
                "ward" to ward.trim(),
                "designation" to cleanDesignation,
                "role" to KazhagaConstants.ROLE_MEMBER,
                "verified" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )

            val batch = db.batch()
            batch.set(db.collection("users").document(uid), userPayload)
            batch.set(db.collection("directory").document(uid), directoryPayload)
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, userPath)
            Result.failure(e)
        }
    }

    suspend fun updateOwnProfile(
        fullName: String,
        mobileNumber: String,
        unionName: String,
        townVillage: String,
        panchayat: String,
        ward: String,
        designation: String
    ): Result<Unit> {
        val currentUid = auth.currentUser?.uid ?: "unauthenticated"
        val userPath = "users/$currentUid"
        return try {
            val uid = requireUserId()
            validateMemberInputs(fullName, mobileNumber, unionName, townVillage, panchayat, ward, designation)
            val cleanDesignation = designation.trim().ifBlank { "உறுப்பினர்" }

            val userUpdates = mapOf(
                "fullName" to fullName.trim(),
                "mobileNumber" to mobileNumber.trim(),
                "district" to KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH,
                "unionName" to unionName.trim(),
                "townVillage" to townVillage.trim(),
                "panchayat" to panchayat.trim(),
                "ward" to ward.trim(),
                "designation" to cleanDesignation,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            val directoryUpdates = mapOf(
                "fullName" to fullName.trim(),
                "district" to KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH,
                "unionName" to unionName.trim(),
                "townVillage" to townVillage.trim(),
                "panchayat" to panchayat.trim(),
                "ward" to ward.trim(),
                "designation" to cleanDesignation,
                "updatedAt" to FieldValue.serverTimestamp()
            )

            val batch = db.batch()
            batch.update(db.collection("users").document(uid), userUpdates)
            batch.update(db.collection("directory").document(uid), directoryUpdates)
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, userPath)
            Result.failure(e)
        }
    }

    suspend fun submitAdminRequest(
        member: UserMember,
        requestedDesignation: String,
        reason: String
    ): Result<Unit> {
        val currentUid = auth.currentUser?.uid ?: "unauthenticated"
        val path = "admin_requests/$currentUid"
        return try {
            val uid = requireUserId()
            require(requestedDesignation.trim().length in 2..80) {
                "கோரும் பொறுப்பு 2 முதல் 80 எழுத்துக்களுக்குள் இருக்க வேண்டும்."
            }
            require(reason.trim().length in 4..300) {
                "காரணம் குறைந்தது 4 எழுத்துக்கள் இருக்க வேண்டும்."
            }

            val payload = mapOf(
                "userId" to uid,
                "fullName" to member.fullName,
                "mobileNumber" to member.mobileNumber,
                "district" to KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH,
                "unionName" to member.unionName,
                "requestedDesignation" to requestedDesignation.trim(),
                "reason" to reason.trim(),
                "status" to KazhagaConstants.STATUS_PENDING,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("admin_requests").document(uid).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun bootstrapChiefAdminRecord(member: UserMember): Result<Unit> {
        val currentUid = auth.currentUser?.uid ?: "unauthenticated"
        val path = "admins/$currentUid"
        return try {
            val uid = requireUserId()
            val email = auth.currentUser?.email
            val adminPayload = buildMap<String, Any> {
                put("uid", uid)
                put("fullName", member.fullName)
                put("mobileNumber", member.mobileNumber)
                if (!email.isNullOrBlank()) put("email", email)
                put("adminLevel", KazhagaConstants.ROLE_CHIEF_ADMIN)
                put("district", KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH)
                put("unionScope", "மாவட்டம் முழுவதும்")
                put("approved", true)
                put("createdBy", uid)
                put("createdAt", FieldValue.serverTimestamp())
                put("updatedAt", FieldValue.serverTimestamp())
            }

            val batch = db.batch()
            batch.set(db.collection("admins").document(uid), adminPayload)
            batch.update(
                db.collection("users").document(uid),
                mapOf(
                    "role" to KazhagaConstants.ROLE_CHIEF_ADMIN,
                    "verified" to true,
                    "memberStatus" to KazhagaConstants.STATUS_ACTIVE,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                db.collection("directory").document(uid),
                mapOf(
                    "role" to KazhagaConstants.ROLE_CHIEF_ADMIN,
                    "verified" to true,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun createAndApproveAdmin(
        targetMember: UserMember,
        unionScope: String,
        hasPendingRequest: Boolean
    ): Result<Unit> {
        val path = "admins/${targetMember.userId}"
        return try {
            val chiefUid = requireUserId()
            require(targetMember.userId.isNotBlank()) { "உறுப்பினர் UID காலியாக உள்ளது." }
            require(unionScope.trim().length in 2..60) { "ஒன்றிய வரம்பு 2..60 எழுத்துக்களுக்குள் இருக்க வேண்டும்." }

            val adminPayload = mapOf(
                "uid" to targetMember.userId,
                "fullName" to targetMember.fullName,
                "mobileNumber" to targetMember.mobileNumber,
                "adminLevel" to KazhagaConstants.ROLE_ADMIN,
                "district" to KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH,
                "unionScope" to unionScope.trim(),
                "approved" to true,
                "createdBy" to chiefUid,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )

            val batch = db.batch()
            batch.set(db.collection("admins").document(targetMember.userId), adminPayload)
            batch.update(
                db.collection("users").document(targetMember.userId),
                mapOf(
                    "role" to KazhagaConstants.ROLE_ADMIN,
                    "verified" to true,
                    "memberStatus" to KazhagaConstants.STATUS_ACTIVE,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                db.collection("directory").document(targetMember.userId),
                mapOf(
                    "role" to KazhagaConstants.ROLE_ADMIN,
                    "verified" to true,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            if (hasPendingRequest) {
                batch.update(
                    db.collection("admin_requests").document(targetMember.userId),
                    mapOf(
                        "status" to "approved",
                        "reviewedBy" to chiefUid,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun approveAdminRequest(request: AdminRequest): Result<Unit> {
        val path = "admins/${request.userId}"
        return try {
            val chiefUid = requireUserId()
            val adminPayload = mapOf(
                "uid" to request.userId,
                "fullName" to request.fullName,
                "mobileNumber" to request.mobileNumber,
                "adminLevel" to KazhagaConstants.ROLE_ADMIN,
                "district" to KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH,
                "unionScope" to request.unionName,
                "approved" to true,
                "createdBy" to chiefUid,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )

            val batch = db.batch()
            batch.set(db.collection("admins").document(request.userId), adminPayload)
            batch.update(
                db.collection("users").document(request.userId),
                mapOf(
                    "role" to KazhagaConstants.ROLE_ADMIN,
                    "verified" to true,
                    "designation" to request.requestedDesignation,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                db.collection("directory").document(request.userId),
                mapOf(
                    "role" to KazhagaConstants.ROLE_ADMIN,
                    "verified" to true,
                    "designation" to request.requestedDesignation,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                db.collection("admin_requests").document(request.userId),
                mapOf(
                    "status" to "approved",
                    "reviewedBy" to chiefUid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun rejectAdminRequest(userId: String): Result<Unit> {
        val path = "admin_requests/$userId"
        return try {
            val chiefUid = requireUserId()
            db.collection("admin_requests").document(userId)
                .update(
                    mapOf(
                        "status" to "rejected",
                        "reviewedBy" to chiefUid,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun setAdminApproval(adminRecord: AdminRecord, approved: Boolean): Result<Unit> {
        val path = "admins/${adminRecord.uid}"
        return try {
            requireUserId()
            val newRole = if (approved) adminRecord.adminLevel else KazhagaConstants.ROLE_MEMBER
            val batch = db.batch()
            batch.update(
                db.collection("admins").document(adminRecord.uid),
                mapOf(
                    "approved" to approved,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                db.collection("users").document(adminRecord.uid),
                mapOf(
                    "role" to newRole,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                db.collection("directory").document(adminRecord.uid),
                mapOf(
                    "role" to newRole,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun verifyMember(memberUid: String, verified: Boolean, status: String): Result<Unit> {
        val path = "users/$memberUid"
        return try {
            requireUserId()
            val batch = db.batch()
            batch.update(
                db.collection("users").document(memberUid),
                mapOf(
                    "verified" to verified,
                    "memberStatus" to status,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                db.collection("directory").document(memberUid),
                mapOf(
                    "verified" to verified,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun publishNotification(
        title: String,
        message: String,
        category: String,
        targetUnion: String,
        authorName: String,
        priority: String
    ): Result<Unit> {
        val notificationId = "notif_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "notifications/$notificationId"
        return try {
            val uid = requireUserId()
            require(title.trim().length in 2..120) { "தலைப்பு 2 முதல் 120 எழுத்துக்களுக்குள் இருக்க வேண்டும்." }
            require(message.trim().length in 2..1500) { "செய்தி 2 முதல் 1500 எழுத்துக்களுக்குள் இருக்க வேண்டும்." }

            val payload = mapOf(
                "title" to title.trim(),
                "message" to message.trim(),
                "category" to category,
                "district" to KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH,
                "targetUnion" to targetUnion.trim().ifBlank { "அனைத்தும்" },
                "authorUid" to uid,
                "authorName" to authorName.trim().ifBlank { "மாவட்ட நிர்வாகம்" },
                "priority" to priority,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("notifications").document(notificationId).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteNotification(notificationId: String): Result<Unit> {
        val path = "notifications/$notificationId"
        return try {
            requireUserId()
            require(notificationId.isNotBlank()) { "அறிவிப்பு ID காலியாக உள்ளது." }
            db.collection("notifications").document(notificationId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    private fun validateMemberInputs(
        fullName: String,
        mobileNumber: String,
        unionName: String,
        townVillage: String,
        panchayat: String,
        ward: String,
        designation: String
    ) {
        require(fullName.trim().length in 2..80) {
            "முழுப் பெயர் 2 முதல் 80 எழுத்துக்களுக்குள் இருக்க வேண்டும்."
        }
        val cleanPhone = mobileNumber.trim()
        require(cleanPhone.length in 10..20) {
            "சரியான கைபேசி எண்ணை உள்ளிடவும் (குறைந்தது 10 இலக்கங்கள்)."
        }
        require(unionName.trim().length in 2..60) {
            "ஒன்றியம் / நகரம் பெயர் 2 முதல் 60 எழுத்துக்களுக்குள் இருக்க வேண்டும்."
        }
        require(townVillage.trim().length in 2..60) {
            "ஊர் / கிராமம் பெயர் 2 முதல் 60 எழுத்துக்களுக்குள் இருக்க வேண்டும்."
        }
        require(panchayat.trim().length in 1..60) {
            "ஊராட்சிப் பெயரை உள்ளிடவும்."
        }
        require(ward.trim().length in 1..20) {
            "வார்டு எண்ணை உள்ளிடவும்."
        }
        require(designation.trim().length <= 60) {
            "பொறுப்பு 60 எழுத்துக்களுக்குள் இருக்க வேண்டும்."
        }
    }

    private fun logStreamError(
        error: Throwable,
        operationType: OperationType,
        path: String,
        expectedUid: String
    ) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) return
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == expectedUid) {
            handleFirestoreError(exceptionToLog, operationType, path)
        }
    }
}
