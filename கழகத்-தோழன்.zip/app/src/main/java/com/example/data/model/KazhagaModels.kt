package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

object KazhagaConstants {
    const val DISTRICT_VILLUPURAM_SOUTH = "விழுப்புரம் தெற்கு"

    val VILLUPURAM_SOUTH_UNIONS = listOf(
        "விழுப்புரம் நகரம்",
        "விழுப்புரம் ஒன்றியம்",
        "கோலியனூர் ஒன்றியம்",
        "காணை ஒன்றியம்",
        "வளவனூர் பேரூராட்சி",
        "விக்கிரவாண்டி ஒன்றியம்",
        "விக்கிரவாண்டி பேரூராட்சி",
        "திருவெண்ணெய்நல்லூர் ஒன்றியம்",
        "திருவெண்ணெய்நல்லூர் பேரூராட்சி",
        "முகையூர் ஒன்றியம்",
        "அரகண்டநல்லூர் பேரூராட்சி"
    )

    val NOTIFICATION_CATEGORIES = listOf(
        "அறிவிப்பு",
        "கூட்டம்",
        "அவசரம்",
        "நிகழ்வு"
    )

    const val ROLE_MEMBER = "member"
    const val ROLE_ADMIN = "admin"
    const val ROLE_CHIEF_ADMIN = "chief_admin"

    const val STATUS_ACTIVE = "active"
    const val STATUS_PENDING = "pending"
    const val STATUS_SUSPENDED = "suspended"

    const val BOOTSTRAP_CHIEF_ADMIN_EMAIL = "pavithran301101@gmail.com"
}

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

@Keep
@IgnoreExtraProperties
data class UserMember(
    @DocumentId val id: String = "",
    val userId: String = "",
    val fullName: String = "",
    val mobileNumber: String = "",
    val district: String = KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH,
    val unionName: String = "",
    val townVillage: String = "",
    val panchayat: String = "",
    val ward: String = "",
    val designation: String = "உறுப்பினர்",
    val role: String = KazhagaConstants.ROLE_MEMBER,
    val memberStatus: String = KazhagaConstants.STATUS_ACTIVE,
    val verified: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class DirectoryMember(
    @DocumentId val id: String = "",
    val userId: String = "",
    val fullName: String = "",
    val district: String = KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH,
    val unionName: String = "",
    val townVillage: String = "",
    val panchayat: String = "",
    val ward: String = "",
    val designation: String = "உறுப்பினர்",
    val role: String = KazhagaConstants.ROLE_MEMBER,
    val verified: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class AdminRecord(
    @DocumentId val id: String = "",
    val uid: String = "",
    val fullName: String = "",
    val mobileNumber: String = "",
    val email: String? = null,
    val adminLevel: String = KazhagaConstants.ROLE_ADMIN,
    val district: String = KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH,
    val unionScope: String = "",
    val approved: Boolean = false,
    val createdBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class NotificationItem(
    @DocumentId val id: String = "",
    val title: String = "",
    val message: String = "",
    val category: String = "அறிவிப்பு",
    val district: String = KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH,
    val targetUnion: String = "அனைத்தும்",
    val authorUid: String = "",
    val authorName: String = "",
    val priority: String = "normal",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class AdminRequest(
    @DocumentId val id: String = "",
    val userId: String = "",
    val fullName: String = "",
    val mobileNumber: String = "",
    val district: String = KazhagaConstants.DISTRICT_VILLUPURAM_SOUTH,
    val unionName: String = "",
    val requestedDesignation: String = "",
    val reason: String = "",
    val status: String = KazhagaConstants.STATUS_PENDING,
    val reviewedBy: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

fun roleDisplayTamil(role: String): String = when (role) {
    KazhagaConstants.ROLE_CHIEF_ADMIN -> "மாவட்ட தலைமை நிர்வாகி"
    KazhagaConstants.ROLE_ADMIN -> "நிர்வாகி"
    else -> "உறுப்பினர்"
}

fun memberStatusDisplayTamil(status: String): String = when (status) {
    KazhagaConstants.STATUS_ACTIVE -> "செயலில்"
    KazhagaConstants.STATUS_SUSPENDED -> "தற்காலிக நிறுத்தம்"
    else -> "நிலுவையில்"
}
