const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const DISTRICT = "விழுப்புரம் தெற்கு";

const CHIEF_UID = "chief_uid_1";
const CHIEF_EMAIL = "pavithran301101@gmail.com";
const ADMIN_UID = "admin_bob_2";
const MEMBER_UID = "member_alice_3";
const OTHER_UID = "member_charlie_4";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function sampleUserPayload(uid, overrides = {}) {
  const now = new Date(Date.now() - 2000);
  return {
    userId: uid,
    fullName: "கதிரவன் அ",
    mobileNumber: "+919876543210",
    district: DISTRICT,
    unionName: "விழுப்புரம் ஒன்றியம்",
    townVillage: "காணை",
    panchayat: "காணை ஊராட்சி",
    ward: "4",
    designation: "உறுப்பினர்",
    role: "member",
    memberStatus: "active",
    verified: false,
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

function sampleDirectoryPayload(uid, overrides = {}) {
  const now = new Date(Date.now() - 2000);
  return {
    userId: uid,
    fullName: "கதிரவன் அ",
    district: DISTRICT,
    unionName: "விழுப்புரம் ஒன்றியம்",
    townVillage: "காணை",
    panchayat: "காணை ஊராட்சி",
    ward: "4",
    designation: "உறுப்பினர்",
    role: "member",
    verified: false,
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

test("Unauthenticated user: denied across all collections", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(MEMBER_UID).get());
  await assertFails(
    unauthDb.collection("directory").where("district", "==", DISTRICT).get()
  );
  await assertFails(
    unauthDb.collection("notifications").where("district", "==", DISTRICT).get()
  );
  await assertFails(
    unauthDb.collection("admins").doc(ADMIN_UID).get()
  );
  await assertFails(
    unauthDb.collection("users").doc(MEMBER_UID).set(sampleUserPayload(MEMBER_UID))
  );
});

test("Member registration: valid create & profile edit succeed; role escalation & OTP fields fail", async () => {
  const aliceDb = testEnv.authenticatedContext(MEMBER_UID).firestore();

  // Valid member create in users and directory
  await assertSucceeds(
    aliceDb.collection("users").doc(MEMBER_UID).set(sampleUserPayload(MEMBER_UID))
  );
  await assertSucceeds(
    aliceDb.collection("directory").doc(MEMBER_UID).set(sampleDirectoryPayload(MEMBER_UID))
  );

  // Valid partial profile update
  await assertSucceeds(
    aliceDb.collection("users").doc(MEMBER_UID).update({
      fullName: "கதிரவன் அருள்",
      ward: "5",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Member CANNOT change their own role or verified status
  await assertFails(
    aliceDb.collection("users").doc(MEMBER_UID).update({
      role: "admin",
      updatedAt: new Date(Date.now() - 500),
    })
  );
  await assertFails(
    aliceDb.collection("users").doc(MEMBER_UID).update({
      verified: true,
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Member CANNOT self-register directly as admin or inject OTP / id fields
  await assertFails(
    aliceDb.collection("users").doc(OTHER_UID).set(
      sampleUserPayload(OTHER_UID, { role: "admin" })
    )
  );
  const otherDb = testEnv.authenticatedContext(OTHER_UID).firestore();
  await assertFails(
    otherDb.collection("users").doc(OTHER_UID).set(
      sampleUserPayload(OTHER_UID, { role: "admin" })
    )
  );
  await assertFails(
    otherDb.collection("users").doc(OTHER_UID).set(
      sampleUserPayload(OTHER_UID, { otp: "123456" })
    )
  );
  await assertFails(
    otherDb.collection("users").doc(OTHER_UID).set(
      sampleUserPayload(OTHER_UID, { id: OTHER_UID })
    )
  );
});

test("PII Isolation & Query Alignment: members cannot read other users' phone numbers, directory query must filter by district", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    await db.collection("users").doc(OTHER_UID).set(sampleUserPayload(OTHER_UID));
    await db.collection("directory").doc(OTHER_UID).set(sampleDirectoryPayload(OTHER_UID));
  });

  const aliceDb = testEnv.authenticatedContext(MEMBER_UID).firestore();
  // Cross-user private PII read fails
  await assertFails(aliceDb.collection("users").doc(OTHER_UID).get());
  await assertFails(aliceDb.collection("users").where("district", "==", DISTRICT).get());

  // Filtered directory query succeeds; unfiltered query fails
  await assertSucceeds(
    aliceDb.collection("directory").where("district", "==", DISTRICT).get()
  );
  await assertFails(aliceDb.collection("directory").get());
});

test("Chief Admin vs Regular Admin: only District Chief Admin can create/approve admins; spoofed unverified email rejected", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    await db.collection("users").doc(ADMIN_UID).set(
      sampleUserPayload(ADMIN_UID, { role: "admin", verified: true })
    );
    await db.collection("admins").doc(ADMIN_UID).set({
      uid: ADMIN_UID,
      fullName: "நிர்வாகி பாபு",
      mobileNumber: "+919876543211",
      adminLevel: "admin",
      district: DISTRICT,
      unionScope: "காணை ஒன்றியம்",
      approved: true,
      createdBy: CHIEF_UID,
      createdAt: new Date(Date.now() - 5000),
      updatedAt: new Date(Date.now() - 5000),
    });
    await db.collection("users").doc(OTHER_UID).set(sampleUserPayload(OTHER_UID));
    await db.collection("directory").doc(OTHER_UID).set(sampleDirectoryPayload(OTHER_UID));
  });

  const now = new Date(Date.now() - 1000);

  // Spoofed unverified chief email MUST fail
  const spoofedChiefDb = testEnv
    .authenticatedContext(CHIEF_UID, { email: CHIEF_EMAIL, email_verified: false })
    .firestore();
  await assertFails(
    spoofedChiefDb.collection("admins").doc(OTHER_UID).set({
      uid: OTHER_UID,
      fullName: "சார்லி",
      mobileNumber: "+919876543212",
      adminLevel: "admin",
      district: DISTRICT,
      unionScope: "விழுப்புரம் நகரம்",
      approved: true,
      createdBy: CHIEF_UID,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Regular Admin CANNOT create another admin or promote a user's role
  const regularAdminDb = testEnv.authenticatedContext(ADMIN_UID).firestore();
  await assertFails(
    regularAdminDb.collection("admins").doc(OTHER_UID).set({
      uid: OTHER_UID,
      fullName: "சார்லி",
      mobileNumber: "+919876543212",
      adminLevel: "admin",
      district: DISTRICT,
      unionScope: "விழுப்புரம் நகரம்",
      approved: true,
      createdBy: ADMIN_UID,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertFails(
    regularAdminDb.collection("users").doc(OTHER_UID).update({
      role: "admin",
      updatedAt: now,
    })
  );

  // Regular Admin CAN verify a member & publish notification
  await assertSucceeds(
    regularAdminDb.collection("users").doc(OTHER_UID).update({
      verified: true,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    regularAdminDb.collection("notifications").doc("notif_1").set({
      title: "மாவட்ட ஆலோசனைக் கூட்டம்",
      message: "நாளை காலை 10 மணிக்கு விழுப்புரம் தெற்கு மாவட்ட அலுவலகத்தில் கூட்டம் நடைபெறும்.",
      category: "கூட்டம்",
      district: DISTRICT,
      targetUnion: "அனைத்தும்",
      authorUid: ADMIN_UID,
      authorName: "நிர்வாகி பாபு",
      priority: "high",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Verified District Chief Admin CAN create & approve an admin account and promote role
  const chiefDb = testEnv
    .authenticatedContext(CHIEF_UID, { email: CHIEF_EMAIL, email_verified: true })
    .firestore();
  await assertSucceeds(
    chiefDb.collection("admins").doc(OTHER_UID).set({
      uid: OTHER_UID,
      fullName: "சார்லி",
      mobileNumber: "+919876543212",
      adminLevel: "admin",
      district: DISTRICT,
      unionScope: "விழுப்புரம் நகரம்",
      approved: true,
      createdBy: CHIEF_UID,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    chiefDb.collection("users").doc(OTHER_UID).update({
      role: "admin",
      verified: true,
      updatedAt: now,
    })
  );
});

test("Notifications & Admin Requests: member reads district notifications and requests approval; only Chief Admin reviews requests", async () => {
  const now = new Date(Date.now() - 1000);
  const aliceDb = testEnv.authenticatedContext(MEMBER_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID).firestore();
  const chiefDb = testEnv
    .authenticatedContext(CHIEF_UID, { email: CHIEF_EMAIL, email_verified: true })
    .firestore();

  // Member cannot create notifications
  await assertFails(
    aliceDb.collection("notifications").doc("notif_bad").set({
      title: "Fake",
      message: "Unauthorized message",
      category: "அறிவிப்பு",
      district: DISTRICT,
      targetUnion: "அனைத்தும்",
      authorUid: MEMBER_UID,
      authorName: "Alice",
      priority: "normal",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Member can read filtered district notifications
  await assertSucceeds(
    aliceDb.collection("notifications").where("district", "==", DISTRICT).get()
  );

  // Member submits pending admin request
  await assertSucceeds(
    aliceDb.collection("admin_requests").doc(MEMBER_UID).set({
      userId: MEMBER_UID,
      fullName: "கதிரவன் அ",
      mobileNumber: "+919876543210",
      district: DISTRICT,
      unionName: "விழுப்புரம் ஒன்றியம்",
      requestedDesignation: "ஒன்றிய நிர்வாகி",
      reason: "விழுப்புரம் ஒன்றிய உறுப்பினர்களை ஒருங்கிணைக்க நிர்வாகப் பொறுப்பு கோருகிறேன்.",
      status: "pending",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Regular admin cannot list or approve admin_requests
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("admins").doc(ADMIN_UID).set({
      uid: ADMIN_UID,
      fullName: "நிர்வாகி பாபு",
      mobileNumber: "+919876543211",
      adminLevel: "admin",
      district: DISTRICT,
      unionScope: "காணை ஒன்றியம்",
      approved: true,
      createdBy: CHIEF_UID,
      createdAt: now,
      updatedAt: now,
    });
  });
  await assertFails(
    adminDb.collection("admin_requests").where("district", "==", DISTRICT).get()
  );
  await assertFails(
    adminDb.collection("admin_requests").doc(MEMBER_UID).update({
      status: "approved",
      reviewedBy: ADMIN_UID,
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Chief Admin can list and approve admin_requests
  await assertSucceeds(
    chiefDb.collection("admin_requests").where("district", "==", DISTRICT).get()
  );
  await assertSucceeds(
    chiefDb.collection("admin_requests").doc(MEMBER_UID).update({
      status: "approved",
      reviewedBy: CHIEF_UID,
      updatedAt: new Date(Date.now() - 500),
    })
  );
});
